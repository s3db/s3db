<?php
	/***************************************************************************\
        * S3DB                                                                     *
        * http://www.s3db.org                                                      *
        * Written by Chuming Chen <chumingchen@gmail.com>                          *
        * ------------------------------------------------------------------------ *
        * This program is free software; you can redistribute it and/or modify it  *
        * under the terms of the GNU General Public License as published by the    *
        * Free Software Foundation; either version 2 of the License, or (at your   *
        * option) any later version.                                               *
        * See http://www.gnu.org/copyleft/gpl.html for detail                      *
        \**************************************************************************/
		/***************************************************************************
		/																		  /
		/Modified by Helena Futscher de Deus <helenadeus@gmail.com>				  /
		/																		  /
		/*************************************************************************/

	if(file_exists('../config.inc.php'))
	{
		include('../config.inc.php');
	}
	else
	{
		Header('Location: index.php');
		exit;
	}
	 //ini_set("include_path", S3DB_SERVER_ROOT.'/pearlib'. PATH_SEPARATOR. ini_get("include_path"));
        //include_once(S3DB_API_INC.'/common_functions.inc.php');
        //require_once(S3DB_API_INC.'/class.db.inc.php');
        include_once(S3DB_SERVER_ROOT.'/s3dbapi/inc/common_functions.inc.php');
        require_once(S3DB_SERVER_ROOT.'/s3dbapi/inc/class.db.inc.php');
        //require_once('Structures/DataGrid.php');
        session_start();
	if(!isset($_SESSION['user']))
	{
		Header('Location: ../login.php?error=2');
		exit;
	}
        Header("Cache-control: private"); //IE fix
	 {
                if (ereg('s3db_',$name))
                {
                        $extra_vars .= '&' . $name . '=' . urlencode($value);
                }
        }

        if ($extra_vars)
        {
                $extra_vars = '?' . substr($extra_vars,1,strlen($extra_vars));
        }

        /* Program starts here */
        $tpl = CreateObject('s3dbapi.Template', $GLOBALS['s3db_info']['server']['template_dir']);
        $tpl->set_file(array(
                'statement' => 'statement.tpl',
        ));
        //$tpl->set_var('uri_base', S3DB_URI_BASE);
	
	//include(S3DB_SERVER_ROOT.'/header.inc.php');
	 $tpl->set_var('image_path', '..');
	$tpl->set_var('section_num', '3');
	
	$tpl->set_file(array('map'=> 'map.tpl', 'footer'=>'footer.tpl'));
	 $tpl->set_var('website_title',  $GLOBALS['s3db_info']['server']['site_title'].' - map');
	$tpl->set_block('map', 'top', '_map');
        $tpl->fp('_output', 'top', True);
	//if($_GET['project_id'] !='')
	//	$_SESSION['working_project'] = $_GET['project_id'];
	$subjects = get_distinct_subjects();	
	$project_data = get_project_info($_REQUEST['project_id']);
	
	if($_REQUEST['project_id'] == '')
        {
                $tpl->set_var('message', 'You are not working with any project yet. Please select a working <a href="../project/index.php">Project</a> by clicking the <b>Name</b> of project first.');
        }

	else if(count($subjects) < 0)
	{
                $tpl->set_var('message', 'You do not have any rule yet. Please create a <a href="../resource/index.php">Resource</a>, then create some rules for it first first.');

	}

	elseif (($_SESSION['user']['account_lid'] != 'Admin') && (($project_data['project_owner'] != $_SESSION['user']['account_id'] &&	find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) == '') ||		 find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) != 0 && find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) != 1 && find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) != 2 && find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) != 3))
		{
			
			#echo $project_data['project_owner'].$_SESSION['user']['account_id'];
			#echo find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']);
			
			$tpl->set_var('message', 'You are not allowed on this project. ');
		
		}

	else 
	{
		$project = get_project_info();
		$tpl->set_var('get_proj_id', '?project_id='.$_REQUEST['project_id']);
		$tpl->set_var('current_stage', 'Project: <b>'.$project['project_name'].'</b>');
		$tpl->set_block('map', 'middle', '_map');
		set_up_applet();	
        	$tpl->fp('_output', 'middle', True);
	}
	$tpl->set_var('width', '1000');
	$tpl->set_var('initialXMLFile', 'tmp/project'.$_REQUEST['project_id'].'.xml');
	$tpl->set_var('content_width', '90%');
	$tpl->set_var('height', '700');
	//$tpl->set_var('message', 'Under Development');
        //$tpl->fp('_output', 'top', True);
	
        //$tpl->parse('_output', 'footer', True);
        $tpl->pfp('out','_output');
	
	function set_up_applet()
	{
		$initialXMLFile = "tmp/project".$_REQUEST['project_id'].".xml";
		//echo $initialXMLFile;
		//if (is_writable($initialXMLFile)) {

   		if (!$handle = fopen($initialXMLFile, 'w')) {
        	 	echo "Cannot open file ($initialXMLFile)";
        		 exit;
   		}

   		if (fwrite($handle, create_graph_string()) === FALSE) {
       			echo "Cannot write to file ($initialXMLFile)";
       			exit;
   		}
   
   		fclose($handle);

		//} else {
   		//	echo "The file $filename is not writable";
		//} 
	}

	function create_graph_string()
	{
		$filename = 'Graph.xml';
		$chunksize = 1024;
		$fh = fopen($filename, 'r');
		if($fh == false)
		{
			return '';
		}
		$xmlfileStr = '';
		while(!feof($fh))
		{
			$xmlfileStr .= fread($fh, $chunksize);
		}
		fclose($fh);
		$xmlfileStr .= sprintf("%s\n", '<TOUCHGRAPH_LB version="1.20">');
		$xmlfileStr .= create_node_set();	
		$xmlfileStr .= create_edge_set();	
		//echo $xmlfileStr;
		$xmlfileStr .= create_params();	
		$xmlfileStr .= sprintf("%s\n", '</TOUCHGRAPH_LB>');
		//echo $xmlfileStr;
		return $xmlfileStr;
		
	}
	
	function get_project_info()
	{
		$db= $_SESSION['db'];
		$sql = "select * from s3db_project where project_id='".$_REQUEST['project_id']."'";
		$db->query($sql, __LINE__, __FILE__);
		if($db->next_record())
		{
			$project = Array('project_id'=>$db->f('project_id'),
					'project_name'=>$db->f('project_name'),
					'project_owner'=>$db->f('project_owner'),
					'project_description'=>$db->f('project_description'),
					'project_status'=>$db->f('project_status'),
					'created_on'=>$db->f('created_on'),
					'created_by'=>$db->f('created_by'),
					'modified_by'=>$db->f('modified_by'),
					'modified_on'=>$db->f('modified_on'));
		}
		return $project; 
	}

	function create_node_set()
	{
		$node_set_str = sprintf("\t%s\n", '<NODESET>');
		$node_set_str .= create_project_node();
		//$node_set_str .= create_uid_node();
		$node_set_str .= create_subject_nodes();
		$node_set_str .= create_object_nodes();
		$node_set_str .= sprintf("\t%s\n", '</NODESET>');
		//echo $node_set_str;	
		return $node_set_str;	
	}

	function create_subject_nodes()
	{
		$subject_node='';	
		//$db = $_SESSION['db'];
		//$sql = "select distinct subject from s3db_rule";
		//$db->query($sql, __LINE__, __FILE__);
		//while($db->next_record())
		$subjects = get_distinct_subjects();
		foreach($subjects as $i =>$value)
		{
			//Lena -created this session because map doesn't allow more than 1 get, but for queryresource to run properly we need at least 2 get's
			$_SESSION['project_on_map'] = $_REQUEST['project_id'];
			
			#.chr(38).'entity_id='.$_REQUEST['entity_id'].'';
			$subject = $subjects[$i]['subject'];
			$resource_id = find_resource_id($subject);
			//echo $resource_id;
			//echo $subject;
			$subject_node .= sprintf("\t\t%s\n", '<NODE nodeID="'.$subject.'">');
			//if($subject =='project'.$_SESSION['working_project'])
				$subject_node .= sprintf("\t\t\t%s\n", '<NODE_LOCATION x="0" y="0" visible="false"/>');
			//else
			//	$subject_node .= sprintf("\t\t\t%s\n", '<NODE_LOCATION x="0" y="0" visible="false"/>');
			$subject_node .= sprintf("\t\t\t%s\n", '<NODE_HINT hint="" width="300" height="-1" isHTML="true"/>');
			$subject_node .= sprintf("\t\t\t%s\n", '<NODE_LABEL label="'.$subject.'" shape="2" backColor="FF0000" textColor="FFFFFF" fontSize="12"/>');
			$subject_node .= sprintf("\t\t\t%s\n", '<NODE_URL url="../resource/queryresource_main_page.php?entity_id='.$resource_id.'&amp;project_id='.$_REQUEST['project_id'].'" urlIsLocal="true" urlIsXML="false"/>');
			//$subject_node .= sprintf("\t\t\t%s\n", '<NODE_URL url="" urlIsLocal="false" urlIsXML="false"/>');
			$subject_node .= sprintf("\t\t%s\n", '</NODE>');
		}
		return $subject_node;		
	}
	
	function get_distinct_subjects()
	{
		$db = $_SESSION['db'];
		//$sql = "select distinct subject from s3db_rule where rule_id in (select distinct rule_id from s3db_statement)";
		$sql = "select distinct subject from s3db_rule where project_id='".$_REQUEST['project_id']."'";
		//echo $sql;
		$db->query($sql, __LINE__, __FILE__);
		while($db->next_record())
		{
			$subjects[] = Array('subject'=>$db->f('subject'));
		}
		//print_r($subjects);
		return $subjects;
	}	
	function create_object_nodes()
	{
		$subject_nodes = get_distinct_subjects();
		//print_r($subject_nodes);
		$object_node='';	
		$db = $_SESSION['db'];
		//$sql = "select distinct object from s3db_rule where rule_id in (select distinct rule_id from s3db_statement)";
		$sql = "select distinct object from s3db_rule where project_id='".$_REQUEST['project_id']."'";
		$db->query($sql, __LINE__, __FILE__);
		while($db->next_record())
		{
			//echo " asdas ".$object;
			$object = $db->f('object');
			if(!object_is_resource($subject_nodes, $object) && $object != 'UID')
			//if(!object_is_resource($object) && $object != 'UID')
			{
			$object_node .= sprintf("\t\t%s\n", '<NODE nodeID="'.$object.'">');
			$object_node .= sprintf("\t\t\t%s\n", '<NODE_LOCATION x="0" y="0" visible="false"/>');
			$object_node .= sprintf("\t\t\t%s\n", '<NODE_HINT hint="" width="300" height="-1" isHTML="false"/>');
			$object_node .= sprintf("\t\t\t%s\n", '<NODE_LABEL label="'.$object.'" shape="2" backColor="336600" textColor="FFFF00" fontSize="12"/>');
			$object_node .= sprintf("\t\t\t%s\n", '<NODE_URL url="" urlIsLocal="false" urlIsXML="false"/>');
			$object_node .= sprintf("\t\t%s\n", '</NODE>');
			}
		}
		//echo $object_node;		
		return $object_node;		
	}
	
	function object_is_resource($subject_nodes, $object)
	{
		foreach($subject_nodes as $i => $value)
		{		
			if($object == $subject_nodes[$i]['subject'])
			{
			//	echo $object;
				return True;
			}
		}
		return False;
	}
	function create_project_node()
	{
		$project =get_project_info();
		$project_node .= sprintf("\t\t%s\n",'<NODE nodeID="'.$project['project_name'].'">');
		$project_node .= sprintf("\t\t\t%s\n", '<NODE_LOCATION x="0" y="0" visible="true"/>');
		$project_node .= sprintf("\t\t\t%s\n",'<NODE_HINT hint="'.str_replace("\"", "", $project['project_description']).'" width="300" height="-1" isHTML="false"/>');
		$project_node .= sprintf("\t\t\t%s\n", '<NODE_LABEL label="'.$project['project_name'].'" shape="3" backColor="0000FF" textColor="FFFF00" fontSize="12"/>');
		$project_node.= sprintf("\t\t\t%s\n",'<NODE_URL url="" urlIsLocal="false" urlIsXML="false"/>');
		$project_node .= sprintf("\t\t%s\n", '</NODE>');
		return $project_node;
	}

	function create_uid_node()
	{
		$uid_node .= sprintf("\t\t%s\n",'<NODE nodeID="UID">');
		$uid_node .= sprintf("\t\t\t%s\n", '<NODE_LOCATION x="0" y="0" visible="true"/>');
		$uid_node .= sprintf("\t\t\t%s\n",'<NODE_HINT hint="Unique Identifier" width="300" height="-1" isHTML="false"/>');
		$uid_node .= sprintf("\t\t\t%s\n", '<NODE_LABEL label="UID" shape="2" backColor="0000FF" textColor="FFFF00" fontSize="12"/>');
		$uid_node.= sprintf("\t\t\t%s\n",'<NODE_URL url="" urlIsLocal="false" urlIsXML="false"/>');
		$uid_node .= sprintf("\t\t%s\n", '</NODE>');
		return $uid_node;
	}

	function create_params()
	{
		 $params = sprintf("\t%s\n", '<PARAMETERS>');
		 $params .= sprintf("\t\t%s\n", '<PARAM name="offsetX" value=""/>');
		 $params .=sprintf("\t\t%s\n", '<PARAM name="rotateSB" value=""/>');
		 $params .= sprintf("\t\t%s\n", '<PARAM name="zoomSB" value=""/>');
		 $params .=sprintf("\t\t%s\n", '<PARAM name="offsetY" value=""/>');
		 $params .=sprintf("\t%s\n", '</PARAMETERS>');
		return $params;
	}
	
	function create_edge_set()
	{
		$edge_set_str = sprintf("\t%s\n", '<EDGESET>');
		
		$resources = get_resources();
		if(!empty($resources))
		{
			$project =get_project_info();
		 	foreach($resources as $i => $value)
			{
				$edge_set_str .= sprintf("\t\t%s\n", '<EDGE fromID="'.$project['project_name'].'" toID="'.$resources[$i]['subject'].'" label="[Project '.$project['project_name']. '] has resource ['.$resources[$i]['subject'].']" type="1" length="20" visible="false" color="A0A0A0"/>');
				//$edge_set_str .= sprintf("\t\t%s\n", '<EDGE fromID="UID" toID="'.$resources[$i]['subject'].'" label="Rule: [('.$resources[$i]['subject'].') has UID (UID)]" type="1" length="20" visible="false" color="A0A0A0"/>');
			}		
		}
	
		$rules = get_rules();		
		for($i= 0; $i< count($rules); $i++)
		{
			//echo $rules[$i]['subject'];
			if($rules[$i]['object'] != 'UID')
			{
				$edge_set_str .= sprintf("\t\t%s\n", '<EDGE fromID="'.$rules[$i]['subject'].'" toID="'.$rules[$i]['object'].'" label="Rule: [('.$rules[$i]['subject'].') '.$rules[$i]['verb'].' ('.$rules[$i]['object'].')] was created_on '.substr($rules[$i]['created_on'], 0, 19).' by '.find_user($rules[$i]['created_by']).'" type="1" length="40" visible="true" color="A0A0A0"/>');
			}
		}
		$edge_set_str .= sprintf("\t%s\n", '</EDGESET>');
		return $edge_set_str;
	}
	
	function find_user($id)
	{
		$db = $_SESSION['db'];
		$sql = "select account_lid from s3db_account where account_id ='".$id."'";
		$db->query($sql, __LINE__, __FILE__);
		if($db->next_record())
			return $db->f('account_lid');
		return '';
	}
	
	function get_resources()
	{
		$db = $_SESSION['db'];
		//$sql = "select distinct subject from s3db_rule where rule_id in (select distinct rule_id from s3db_statement)";
		$sql = "select distinct subject from s3db_rule where project_id='".$_REQUEST['project_id']."'";
		$db->query($sql, __LINE__, __FILE__);
		while($db->next_record())
		{
			$resources[] = Array('subject'=>$db->f('subject'));
		}
		return $resources;		
	}	
		
	function get_rules()
	{
		$db = $_SESSION['db'];
		//$sql = "select * from s3db_rule where object !='UID' and rule_id in (select distinct rule_id from s3db_statement) order by rule_id";
		//$sql = "select * from s3db_rule where rule_id in (select distinct rule_id from s3db_statement) order by rule_id";
		$sql = "select * from s3db_rule where project_id='".$_REQUEST['project_id']."' order by rule_id";
		//echo $sql;
		$db->query($sql, __LINE__, __FILE__);
		while($db->next_record())
		{
			$rules[] = Array('rule_id'=>$db->f('rule_id'),
					//'owner'=>$db->f('owner'),
					'resource_id'=>$db->f('resource_id'),
					'subject'=>$db->f('subject'),
					'verb'=>$db->f('verb'),
					'object'=>$db->f('object'),
					'notes'=>$db->f('notes'),
					'created_on'=>$db->f('created_on'),
					'created_by'=>$db->f('created_by'),
					'modified_on'=>$db->f('modified_on'),
					'modified_by'=>$db->f('modified_by'));
		}
		//echo count($rules);		
		return $rules;		
	}	
	
	 
?>
