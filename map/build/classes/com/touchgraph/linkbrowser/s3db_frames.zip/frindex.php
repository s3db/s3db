<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE> S3DB  </TITLE>
<META NAME="Generator" CONTENT="EditPlus">
<META NAME="Author" CONTENT="">
<META NAME="Keywords" CONTENT="">
<META NAME="Description" CONTENT="">
<FRAMESET ROWS="20%,80%">
	<FRAME SRC="../frames/HeaderFrame.php" NAME="header" >
	<?php 
	if ($_REQUEST['project_id']!=='' && $_REQUEST['resource_id']!=='') echo '<FRAME SRC="../frames/RestofFrames.php?project_id='.$_REQUEST['project_id'].'&resource_id='.$_REQUEST['resource_id'].'" NAME="rest_of_frames">'; ?>
</FRAMESET>

</HEAD>

<BODY>

</BODY>
</HTML>