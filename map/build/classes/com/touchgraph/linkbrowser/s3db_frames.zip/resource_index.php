<?php
	/***************************************************************************\
        * S3DB                                                                     *
        * http://www.s3db.org                                                      *
        * Written by Chuming Chen <chumingchen@gmail.com>                          *
        * ------------------------------------------------------------------------ *
        * This program is free software; you can redistribute it and/or modify it  *
        * under the terms of the GNU General Public License as published by the    *
        * Free Software Foundation; either version 2 of the License, or (at your   *
        * option) any later version.                                               *
        * See http://www.gnu.org/copyleft/gpl.html for detail                      *
        \**************************************************************************/

	if(file_exists('../config.inc.php'))
	{
		include('../config.inc.php');
	}
	else
	{
		Header('Location: index.php');
		exit;
	}
	
		
	include(S3DB_SERVER_ROOT.'/header_main_page.inc.php');
	/*if($_GET['page']!='' )
                $_SESSION['current_page'] = $_GET['page'];
	
	if($_GET['sort']!='')
	{
		$sortorder = $_GET['sort'];
		$direction =$_GET['dir'];
	}
	else
	{
		$sortorder = 'resource_id';
		$direction =$_GET['dir'];
	}*/
	//echo $sortorder;
	
	
$resources = list_resources($_REQUEST['project_id']);
if ($_REQUEST['project_id']!='' && count($resources)>=1 ) echo '<body onload="parent.ProjectsFrames.location.href = \'../frames/ProjectsFrames.php?project_id='.$_REQUEST['project_id'].'\'">';

	$tpl->set_file(array('resource'=> 'resource_main_page.tpl'));
	$tpl->set_var('image_path', '..');
	$tpl->set_var('section_num', '3');
	#$tpl->set_var('action_url', 'queryresource_main_page.php{get_proj_id}');
	$tpl->set_var('website_title',  $GLOBALS['s3db_info']['server']['site_title'].' - resources');
	$tpl->set_block('resource', 'top', '_resource');
        $tpl->fp('_output', 'top', True);

	
	$project_data = get_project_info($_REQUEST['project_id']);
	
	if($_REQUEST['project_id'] == '')
	{
		//echo " I am here";
		$tpl->set_var('message', 'You are not working with any project yet. Please select a working <a href="../project/index.php">project</a> by clicking the <b>Name</b> of project.');	
	}
	
	
	
	
		
		//Lena's code: This bit will block entry on a project for users not allowed on that project
	
	 #echo find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']);	
	
	
	elseif (($_SESSION['user']['account_lid'] != 'Admin') && (($project_data['project_owner'] != $_SESSION['user']['account_id'] &&	find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) == '') ||		 find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) != 0 && find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) != 1 && find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) != 2 && find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) != 3))
		{
			
			#echo find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']);
			
			$tpl->set_var('message', 'You are not allowed on this project. ');
		
		}
		else
		{
		
		
		
		
		$tpl->set_var('current_stage', 'Project: <b>'.$project_info['name'].'</b>');
		$tpl->set_var('content_width', '100%');
		

			$tpl->set_var('Resources', 'Select a resource');
			$tpl->set_var('resources_list', create_resources_list_main_page());
			
			
		
		#This will have to be included on each script where resource_list is visible. Was removed from common_functions	  
		
		if(find_user_acl($_SESSION['user']['account_id'], $project_info['id']) == '3' || $project_info['owner'] == $_SESSION['user']['account_id']) 
		{
                        //$resources_list= '<a href="createresource.php">Add Resource</a><br /><br />';
                         #echo 'ola';
						 #$new_resource_button ='<br /><br /><input type="button" value="New Resource" size="20" onClick="parent.location=\'{uri_base}/resource/createresource.php?project_id='.$_REQUEST['project_id'].'\'"><br /><br />';
		}
               
		$tpl->set_var('new_resource_button', $new_resource_button);
		
		
		$resources = list_resources($_REQUEST['project_id']);
		
		#The rest of the page will run on a second iframe (main_page)

		

		if(count($resources) == 0)
		{
                	if(find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) == '3' ||  $project_info['owner']== $_SESSION['user']['account_id'])
				$tpl->set_var('message', 'You do not have any resource yet. Please create a new resource first.');	
			else
				$tpl->set_var('message', 'You do not have any resource yet. You also do not have permission to create new resource.');	
		}
		if($_REQUEST['entity_id'] == '')
		{
			$project = get_project_info($_REQUEST['project_id']);
			$tpl->set_var('project_name', $project['project_name']);
			$tpl->set_var('project_description', $project['project_description']);
			$tpl->set_var('created_on', substr($project['created_on'], 0, 19));
			$tpl->set_var('created_by', $project['created_by']);
			$tpl->set_var('project_owner', find_project_owner($project['project_owner']));
			$shared_users = list_shared_users($_REQUEST['project_id']);
			 if(count($shared_users) > 0)
			$tpl->set_var('project_acl_datagrid', render_project_acl($shared_users, $sortorder, 'ASC'));
			$tpl->set_block('resource', 'project_intro', '_resource');
        		$tpl->fp('_output', 'project_intro', True);
		}
		
	
	}
		#$tpl->parse('_output', 'footer', True);
        $tpl->pfp('out','_output');

		
	 function list_shared_users($project_id)
        {

                $db = $_SESSION['db'];
                $sql = "select account_id, account_lid, account_uname, acl_rights from s3db_account, s3db_project_acl where account_id in (select distinct account_id from s3db_account_group where group_id in (select account_id from s3db_account where account_id in (select group_id from s3db_account_group where account_id='".$_SESSION['user']['account_id']."'))) and account_type ='u' and account_status='A' and account_id !='".$_SESSION['user']['account_id']."' and acl_project_id='".$project_id."' and acl_account=account_id order by account_lid asc";
		//echo $sql;
                $db->query($sql, __LINE__, __FILE__);
                while($db->next_record())
                {
                        $acl = $db->f('acl_rights');
                        $acl_level_0= ($db->f('acl_rights') =='0')? '0':'';
                        $acl_level_1= ($db->f('acl_rights') =='1')? '1':'';
                        $acl_level_2= ($db->f('acl_rights') =='2')? '2':'';
                        $acl_level_3= ($db->f('acl_rights') =='3')? '3':'';

                        $shared_users[] = Array('account_id' => $db->f('account_id'),
                                         'account_lid' => $db->f('account_lid'),
                                         'account_uname' => $db->f('account_uname'),
                                         'acl_level_0'=>$acl_level_0,
                                         'acl_level_1'=>$acl_level_1,
                                         'acl_level_2'=>$acl_level_2,
                                         'acl_level_3'=>$acl_level_3);

                }

                 $group_users = list_group_users($project_id);
                 if(!empty($group_users) && !empty($shared_users))
                        $users = array_merge($shared_users, $group_users);
                 else if(empty($group_users))
                        $users = $shared_users;
                 else
                        $users = $group_users;
                return $users;
        }
	
	  function list_group_users($project_id)
        {global $resource_info, $project_info;

		$project_owner = $project_info['owner'];
		//echo "aa ".$project_owner;
                $db = $_SESSION['db'];
                $sql = "select account_id, account_lid, account_uname from s3db_account where account_id in (select distinct account_id from s3db_account_group where group_id in (select account_id from s3db_account where account_id in (select group_id from s3db_account_group where account_id='".$_SESSION['user']['account_id']."'))) and account_type ='u' and account_status='A' and account_id !='".$_SESSION['user']['account_id']."' and account_id not in (select acl_account from s3db_project_acl where acl_project_id='".$project_id."') order by account_lid asc";
		//echo $sql;	
                $db->query($sql, __LINE__, __FILE__);
                while($db->next_record())
                {
			$uid = $db->f('account_id');
		//	echo $uid;
		//	echo $project_owner;
			if($project_owner == $uid)
			{
                                  $acl_level_0 ='';
                                  $acl_level_1 ='';
                                  $acl_level_2 ='';
                                  $acl_level_3 ='3';
			}
			else
			{
                                  $acl_level_0 ='0';
                                  $acl_level_1 ='';
                                  $acl_level_2 ='';
                                  $acl_level_3 ='';
			}	
                        $group_users[] = Array('account_id' => $uid,
                                         'account_lid' => $db->f('account_lid'),
                                         'account_uname' => $db->f('account_uname'),
                                         'acl_level_0'=>$acl_level_0,
                                         'acl_level_1'=>$acl_level_1,
                                         'acl_level_2'=>$acl_level_2,
                                         'acl_level_3'=>$acl_level_3);

                }
		//print_r($group_users);
                return $group_users;
        }
/*	
	function get_resource_info($resource_id)
	{
		$db = $_SESSION['db'];
		$sql = "select * from s3db_resource where resource_id='".$resource_id."'";
		$db->query($sql, __LINE__, __FILE__);

		if($db->next_record())
		{
			$resource = Array('resource_id'=>$db->f('resource_id'),
					'project_id'=>$db->f('project_id'),	
					'owner'=>$db->f('owner'),	
					'entity'=>$db->f('entity'),	
					'uid'=>$db->f('uid'),	
					'notes'=>$db->f('notes'),	
					'created_on'=>substr($db->f('created_on'), 0, 19),	
					'created_by'=>$db->f('created_by'),	
					'modified_on'=>$db->f('modified_on'),	
					'modified_by'=>$db->f('modified_by'));
		}
		return $resource;
	}
*/		
	function validate_inputs($resource, $action)
	{
		//print_r($rule);
		if($resource['entity'] == '')
			return 1;
		//else if(is_resource_exists($resource) && $action = 'new')
		//	return 2;
		else 
			return 0;
				
	}
		
	function is_resource_exists($resource)
	{
		$db = $_SESSION['db'];
		$sql = "select resource_id from s3db_resource where entity='".$resource['entity']."' and project_id='".$resource['project_id']."'";	
		//echo $sql;
		$db->query($sql, __LINE__, __FILE__);
		if($db->next_record())
			return True;
		else
			return False;
	}
/*		
	function create_resource($new_resource)
	{
		$db = $_SESSION['db'];
		$uid = find_new_uid($new_resource['entity']);
		if($uid == '-1')
			$uid = 1;
		else
			$uid = intval($uid) + 1;
		$sql = "insert into s3db_resource (project_id, owner, uid,  entity, notes, created_on, created_by) values ('".$new_resource['project_id']."', '".$new_resource['owner']."', '".$uid."', '".$new_resource['entity']."','".$new_resource['notes']."', now(),'".$_SESSION['user']['account_id']."')";
		//echo $sql;
		$db->query($sql, __LINE__, __FILE__);
		$resource_id = $db->get_last_insert_id('s3db_resource', 'resource_id');
		if($resource_id != -1)
		{
			$new_resource['resource_id'] = $resource_id;
			$sql = "insert into s3db_rule (resource_id, project_id, owner, subject, object, verb, notes, created_on, created_by) values ('".$resource_id."', '".$new_resource['project_id']."', '".$new_resource['owner']."', '".$new_resource['entity']."','has', 'UID', '', now(),'".$_SESSION['user']['account_id']."')";	
		//	echo $sql;
			$db->query($sql, __LINE__, __FILE__);
			return True;	
		}
		return False;	
	}
*/
	function find_new_uid($entity)
	{
		$db = $_SESSION['db'];
		$sql = "select max(uid) from s3db_resource where entity = '".$entity."' and project_id='".$_REQUEST['project_id']."'";
		$db->query($sql, __LINE__, __FILE__);
		if($db->next_record())
			return $db->f('max');
		else
			return '-1';
	}

	function is_entity_exists($edited_resource)
	{
		$db = $_SESSION['db'];
		$sql = "select resource_id from s3db_resource where entity = '".$entity."' and project_id='".$_REQUEST['project_id']."'";
		$db->query($sql, __LINE__, __FILE__);
		if($db->next_record())
			return True;
		else
			return False;

	}
	
	function update_resource($edited_resource)
	{
		$db = $_SESSION['db'];
		if(is_entity_exists($edited_resource['entity']))
		{
			$sql = "update s3db_resource set entity='".$edited_resource['entity']."', notes='".$edited_resource['notes']."', modified_on=now(), modified_by='".$_SESSION['user']['account_id']."' where resource_id ='".$edited_resource['resource_id']."'";
		}
		else
		{
			$uid = find_new_uid($edited_resource['entity']);
			if($uid == '-1')
                      		$uid = 1;
                	else
                       		$uid = intval($uid) + 1;
			$sql = "update s3db_resource set entity='".$edited_resource['entity']."', uid ='".$uid."', notes='".$edited_resource['notes']."', modified_on=now(), modified_by='".$_SESSION['user']['account_id']."' where resource_id ='".$edited_resource['resource_id']."'";
				
		}
		$db->query($sql, __LINE__, __FILE__);
		return True;
	}	
	
	 function render_project_acl($datasource, $order, $direction)
        {
                //print_r($datasource);
                $orderBy = $order;
                $dir = $direction;

                // Create the DataGrid, bind it's Data Source
                $dg =& new Structures_DataGrid(20); // Display 20 per page
                $dg->bind($datasource);
                // Define DataGrid's columns            
                $dg->addColumn(new Structures_DataGrid_Column('Login', null, 'account_lid', array('width'=>'15%', 'align'=>'left'), null, 'printAccountLID()'));
                $dg->addColumn(new Structures_DataGrid_Column('User Name', null, 'account_uname', array('15%', 'align'=>'left'), null, 'printAccountUserName()'));
                $dg->addColumn(new Structures_DataGrid_Column('Permissions', null, null, array('align'=>'left'), null, 'printACL()'));

                // Define the Look and Feel
                //$dg->renderer->setTableHeaderAttributes(array('bgcolor'=>'#FFCCFF'));
                $dg->renderer->setTableHeaderAttributes(array('bgcolor'=>'lightyellow'));
                $dg->renderer->setTableEvenRowAttributes(array('bgcolor'=>'#FFFFFF'));
                $dg->renderer->setTableOddRowAttributes(array('bgcolor'=>'#EEEEEE'));
                $dg->renderer->setTableAttribute('width', '100%');
                $dg->renderer->setTableAttribute('align', 'left');
                $dg->renderer->setTableAttribute('border', '1px');
                $dg->renderer->setTableAttribute('cellspacing', '0');
                $dg->renderer->setTableAttribute('cellpadding', '4');
                $dg->renderer->setTableAttribute('class', 'datagrid');
                $dg->renderer->sortIconASC = '&uarr;';
                $dg->renderer->sortIconDESC = '&darr;';

                $htmloutput =  $dg->render();
                $htmloutput .= $dg->renderer->getPaging();

                return $htmloutput;
        }

	function printAccountLID($params)
        {
                extract($params);
                return $record['account_lid'];
        }

        function printAccountUserName($params)
        {
                extract($params);
                return $record['account_uname'];
        }
	 function printACL($params)
        {
                extract($params);
                if($record['acl_level_0'] !='')
                        return 'Level 0 - View only';
                else if($record['acl_level_1']!='')
                        return 'Level 1 - Add/Edit/Delete own data but not rules';
                else if($record['acl_level_2']!='')
                        return 'Level 2 - Add/Edit/Delete any data but not rules';
                else if($record['acl_level_3']!='')
                        return 'Level 3 - Add/Edit/Delete rules and do anything else';
                return $acl;
        }
 
	function render_resources($datasource, $order, $direction)
	{
		//print_r($datasource);
		// Determine sort order and direction as well as the page to display
		$orderBy = $order;
		$dir = $direction;			
		//echo $orderBy;
		//echo $dir;
		// Create the DataGrid, bind it's Data Source
		$dg =& new Structures_DataGrid(15); // Display 20 per page
		$dg->bind($datasource);	
		// Define DataGrid's columns		
	//	$dg->addColumn(new Structures_DataGrid_Column('Project ID', null, 'project_id', array('width'=>'7%', 'align'=>'left'), null, 'printProjectID()'));
		$dg->addColumn(new Structures_DataGrid_Column('Resource ID', null, 'resource_id', array('width'=>'7%', 'align'=>'left'), null, 'printResourceID()'));
		$dg->addColumn(new Structures_DataGrid_Column('Owner', null, 'owner', array('width'=>'5%', 'align'=>'left'), null, 'printOwner()'));
		$dg->addColumn(new Structures_DataGrid_Column('Created Date', null, 'created_on', array('width'=>'12%', 'align'=>'left'), null, 'printCreatedOn()'));
		$dg->addColumn(new Structures_DataGrid_Column('ID', null, 'uid', array('width'=>'5%', 'align'=>'left'), null, 'printID()'));
		$dg->addColumn(new Structures_DataGrid_Column('Entity', null, 'entity', array('width'=>'15%', 'align'=>'left'), null, 'printEntity()'));
		$dg->addColumn(new Structures_DataGrid_Column('Notes', null, 'notes', array('width'=>'25%', 'align'=>'left'), null, 'printNotes()'));
		$dg->addColumn(new Structures_DataGrid_Column('Clone', null, null, array('width'=>'5%', 'align'=>'left'), null, 'printCloneLink()'));
		$dg->addColumn(new Structures_DataGrid_Column('Rules', null, null, array('width'=>'5%', 'align'=>'left'), null, 'printRulesLink()'));
		$dg->addColumn(new Structures_DataGrid_Column('Statements', null, null, array('width'=>'5%', 'align'=>'left'), null, 'printStatementsLink()'));
		$dg->addColumn(new Structures_DataGrid_Column('Action', null, null, array('align'=>'left'), null, 'printActionLink()'));
		//$dg->addColumn(new Structures_DataGrid_Column('Edit', null, null, array('align'=>'left'), null, 'printEditLink()'));
		//$dg->addColumn(new Structures_DataGrid_Column('Delete', null, null, array('align'=>'left'), null, 'printDeleteLink()'));
		
		// Define the Look and Feel
		$dg->renderer->setTableHeaderAttributes(array('bgcolor'=>'#FFCCFF'));		
		$dg->renderer->setTableEvenRowAttributes(array('bgcolor'=>'#FFFFFF'));		
		$dg->renderer->setTableOddRowAttributes(array('bgcolor'=>'#EEEEEE'));		
		$dg->renderer->setTableAttribute('width', '100%');		
		$dg->renderer->setTableAttribute('align', 'center');		
		$dg->renderer->setTableAttribute('border', '0px');		
		$dg->renderer->setTableAttribute('cellspacing', '0');		
		$dg->renderer->setTableAttribute('cellpadding', '4');		
		$dg->renderer->setTableAttribute('class', 'datagrid');		
		$dg->renderer->sortIconASC = '&uarr;';		
		$dg->renderer->sortIconDESC = '&darr;';	
		//$dg->renderer->sortIconASC = '&#94;';		
		//$dg->renderer->sortIconDESC = '&#118;';	
		
		$htmloutput =  $dg->render();	
		//echo $dg->renderer->getPaging();
		$htmloutput .= $dg->renderer->getPaging();

		return $htmloutput;
	}	
		
	function printProjectID($params)
	{
		extract($params);
		return $record['project_id'];
	}	
	
	function printResourceID($params)
	{
		extract($params);
		return $record['resource_id'];
	}	
	
	function printOwner($params)
	{
		extract($params);
		return $record['owner'];
	}
	
	function printCreatedOn($params)
	{
		extract($params);
		return substr($record['created_on'], 0, 19);
	}

	function printEntity($params)
	{
		extract($params);
		return $record['entity'];
	}
		
	function printID($params)
	{
		extract($params);
		return $record['uid'];
	}
		
	function printVerb($params)
	{
		extract($params);
		return $record['verb'];
	}

	 function printActionLink($params)
        {
                //extract($params);
                return  printEditLink($params). ' '.printDeleteLink($params);
        }
	
	function printCloneLink($params)
	{
		extract($params);
			return '<a href="index.php?page='.$_SESSION['current_page'].'&action=clone" title="Clone a resource with a name '.$record['entity'].'">Clone</a>';
	}

	function printRulesLink($params)
	{
		extract($params);
			return '<a href="../rule/index.php?{get_proj_id&}resource_id='.$record['resource_id'].'" title="Rules associated with resource '.$record['resource_id'].'">Rules</a>';
	}
	
	function printStatementsLink($params)
	{
		extract($params);
			return '<a href="../statement/index.php?&resource_id='.$record['resource_id'].'" title="Statement associated with resource '.$record['resource_id'].'">Statements</a>';
	}


	function printEditLink($params)
	{
		extract($params);
		if($record['owner'] == $_SESSION['user']['account_lid'] ||
		get_project_owner() == $_SESSION['user']['acccount_id'] ||
		get_resource_permissions($record['project_id']) >=6)
			return '<a href="index.php?page='.$_SESSION['current_page'].'&action=edit" title="Edit resource '.$record['resource_id'].'">Edit</a>';
		else
			return '&nbsp;';
	}	
	
	function get_resource_permissions($project_id)
	{
		$db= $_SESSION['db'];
		$sql = "select acl_rights from s3db_project_acl where acl_project_id ='".$project_id."' and acl_account='".$_SESSION['user']['account_id']."'";
		$db->query($sql, __LINE__, __FILE__);
		if($db->next_record())
		{
			//echo substr($db->f('acl_rights'), 1, 1). '\n';
			return substr($db->f('acl_rights'), 1, 1);
		}	
		return '';
	}
	
	function printDeleteLink($params)
	{
		extract($params);
		if($record['owner'] == $_SESSION['user']['account_lid'] ||
		get_project_owner() == $_SESSION['user']['acccount_id'] ||
		get_resource_permissions($record['project_id']) == 5 || get_resource_permissions($record['project_id']) == 7)
			return '<a href="deleteresource.php?resource_id='.$record['resource_id'].'&action=delete" title="Delete resource '.$record['resource_id'].'">Delete</a>';
		else
			return '&nbsp;';
	}	
	
	function printNothing($params)
	{
		extract($params);
		return '';
	}	
	
	function printNotes($params)
	{
		extract($params);
		return $record['notes'];
	}
	function find_project_owner($id)
        {
                $db = $_SESSION['db'];
                $sql = "select account_lid, account_uname from s3db_account where account_id='".$id."'";
                $db->query($sql, __LINE__, __FILE__);
                if($db->next_record())
                        return $db->f('account_uname').' ( '.$db->f('account_lid') .' )';
                else 
                        return '';
        }    
	 function get_project_info($project_id)
        {
                $db = $_SESSION['db'];
                $sql = "select * from s3db_project where project_id='".$project_id."'";
                $db->query($sql, __LINE__, __FILE__);
                if($db->next_record())
                {
                        $project_info=Array('project_id'=>$db->f('project_id'),
                                           'project_name'=>$db->f('project_name'),
                                           'project_owner'=>$db->f('project_owner'),
                                           'project_description'=>$db->f('project_description'),
                                           'project_status'=>$db->f('project_status'),
                                           'created_on'=>$db->f('created_on'),
                                           'created_by'=>$db->f('created_by'),
                                           'modified_on'=>$db->f('modified_on'),
                                           'modified_by'=>$db->f('modified_by'));

                }
                return $project_info;
        }

		 function create_resources_list_main_page()

	{global $resource_info, $project_info;
                $distinct_resources = get_distinct_resources();
               
                 $resources_list ='';
               
                if(count($distinct_resources) > 0)
                {
                	#$resources_list.='<form method=POST action = queryresource_main_oselect name="resources" onClick="parent.location=this.options[this.selectedIndex].value" size="15">';
                       $db = $_SESSION['db'];
                        foreach($distinct_resources as $i=>$value)
                        {
                                $resource_id = find_resource_id($distinct_resources[$i]['entity']);
				//echo $resource_id;
                                $sql = "select count(resource_id)  as count from s3db_resource where  project_id='".$_REQUEST['project_id']."' and entity='".$distinct_resources[$i]['entity']."' and iid !=0";
                           //     echo $sql;
                                $db->query($sql, __LINE__, __FILE__);
                                if($db->next_record())
                                        //$resources_list .=' <a href="index.php?entity='.$distinct_resources[$i]['entity'].'">'.$distinct_resources[$i]['entity'].' ('.$db->f('count').')</a><br />';
					if($resource_info['id'] == $resource_id)
							{ #$resources_list .='</form>';                    	
					$resources_list .='<input type="button" onclick="window.location=\'{uri_base}/resource/queryresource_main_page.php{get_proj_id}&entity_id='.$resource_id.'\' value="'.$distinct_resources[$i]['entity'].'"> ('.$db->f('count').')>';}
                                       else 
							{#$resources_list .='</form>';                    	
									   $resources_list .='<input type="button" onclick="window.location=\'{uri_base}/resource/queryresource_main_page.php{get_proj_id}&entity_id='.$resource_id.'\'" value="'.$distinct_resources[$i]['entity'].'"> ('.$db->f('count').')</option><br />';
							}
                        }
                	#$resources_list.='</select>';
                }
                if(find_user_acl($_SESSION['user']['account_id'], $project_info['id']) == '3' || $project_info['owner'] == $_SESSION['user']['account_id']) 
		{
                        //$resources_list= '<a href="createresource.php">Add Resource</a><br /><br />';
                          $resources_list.='<br /><br /><input type="button" value="New Resource" size="20" onClick="window.location=\'{uri_base}/resource/createresource_main_page.php?project_id='.$_REQUEST['project_id'].'\'"><br /><br />';
		}
                return $resources_list;
        }


?>
