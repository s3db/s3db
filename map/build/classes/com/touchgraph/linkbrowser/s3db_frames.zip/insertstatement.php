<?php
	/***************************************************************************\
        * S3DB                                                                     *
        * http://www.s3db.org                                                      *
        * Written by Chuming Chen <chumingchen@gmail.com>                          *
        * ------------------------------------------------------------------------ *
        * This program is free software; you can redistribute it and/or modify it  *
        * under the terms of the GNU General Public License as published by the    *
        * Free Software Foundation; either version 2 of the License, or (at your   *
        * option) any later version.                                               *
        * See http://www.gnu.org/copyleft/gpl.html for detail                      *
        \**************************************************************************/
		/***************************************************************************
		/																		  /
		/Modified by Helena Futscher de Deus <helenadeus@gmail.com>				  /
		/																		  /
		/*************************************************************************/
		
	if(file_exists('../config.inc.php'))
	{
		include('../config.inc.php');
	}
	else
	{
		Header('Location: index.php');
		exit;
	}
	
	ini_set("include_path", S3DB_SERVER_ROOT.'/pearlib'. PATH_SEPARATOR. ini_get("include_path")); 	
	include_once(S3DB_SERVER_ROOT.'/s3dbapi/inc/common_functions.inc.php');
	require_once(S3DB_SERVER_ROOT.'/s3dbapi/inc/class.db.inc.php');
	require_once('Structures/DataGrid.php');
	session_start();
	Header("Cache-control: private"); //IE fix
	if(!isset($_SESSION['user']))
	{
		Header('Location: ../login.php?error=2');
		exit;
	}
	//echo $_SERVER['HTTP_USER_AGENT']['browser'];
	//$browser = get_browser(null, true);
	//echo $browser['browser'];	
	foreach($_GET as $name => $value)
	{
		if (ereg('s3db_',$name))
		{
			$extra_vars .= '&' . $name . '=' . urlencode($value);
		}
	}

	if ($extra_vars)
	{
		$extra_vars = '?' . substr($extra_vars,1,strlen($extra_vars));
	}

	/* Program starts here */
	$tpl = CreateObject('s3dbapi.Template', $GLOBALS['s3db_info']['server']['template_dir']);

	//Lena's - had to put this here because this file doesn't include header.inc 

//Lena's - put this after the link: {get_proj_id}{get_res_id}


	if (isset($_REQUEST['project_id']))
	{$tpl->set_var('get_proj_id', '?project_id='.$_REQUEST['project_id'].'');
	$tpl->set_var('get_proj_id&', 'project_id='.$_REQUEST['project_id'].'&');}
	
	if (isset($_REQUEST['entity_id']))
	{
		$resource_info = Array('id'=>$_REQUEST['entity_id'],
					'entity'=>get_entity($_REQUEST['entity_id']));
				
		$tpl->set_var('get_res_id', '&entity_id='.$_REQUEST['entity_id'].'');
	}


//Lena's - Create the input type hidden with project_id and resource-id for submit buttons: {hidden_project}{hidden_entity} after every submit button
	
	if (isset($_REQUEST['project_id']))
	$tpl-> set_var('hidden_project', '<input type="hidden" name="project_id" value="'.$_REQUEST['project_id'].'">');
	if (isset($_REQUEST['entity_id']))
	$tpl-> set_var('hidden_entity', '<input type="hidden" name="entity_id" value="'.$_REQUEST['entity_id'].'">');

	
		//Lena's: create variable that holds project information and resource information to be available to all script; put this in every function that requires it - global $resource_info, $project_info;
		
		if($_REQUEST['entity_id'] !='')
	{
		$resource_info = Array('id'=>$_REQUEST['entity_id'],
					'entity'=>get_entity($_REQUEST['entity_id']),
					'main_rule' => $_REQUEST['main_rule'],
					'main_resID' => $_REQUEST['main_resID'], 
					'main_res_ent'=> get_entity ($_REQUEST['main_resID']));
	}
		
		if($_REQUEST['project_id'] !='')
	{
		
		
		
		$project_info = Array('id'=>$_REQUEST['project_id'],
					'owner' => get_project_owner($_REQUEST['project_id']),
					'name' => get_project_name($_REQUEST['project_id']));
		
	}
	
//End Lena's
	
	$tpl->set_file(array(
		'statement' => 'statement.tpl',
	));
	//$tpl->set_var('uri_base', S3DB_URI_BASE);
	$tpl->set_var('action_url', 'insertstatement.php{get_proj_id}{get_res_id}&resource_id='.$_REQUEST['resource_id'].'&rule_id='.$_REQUEST['rule_id'].'');
	if(!empty($_GET['resource_id']))
        {
                $inserting_resource = get_resource_info($_GET['resource_id']);
                $tpl->set_var('resource_id', $_GET['resource_id']);
        }
        else
        {
                $inserting_resource = get_resource_info($_POST['resource_id']);
                $tpl->set_var('resource_id', $_POST['resource_id']);
        }
	if(!empty($_GET['rule_id']))
        {
                $rule= get_rule_info($_GET['rule_id']);
                $tpl->set_var('rule_id', $_GET['rule_id']);
	}
	else
	{
                $rule= get_rule_info($_POST['rule_id']);
                $tpl->set_var('rule_id', $_POST['rule_id']);

	}

	$project_data = get_project_info($_REQUEST['project_id']);

	if ($_REQUEST['project_id'] == '')
	{
		$tpl->set_var('message', 'You are not working with any project yet. Please select a working <a href="../project/index.php">project</a> by clicking the <b>Name</b> of project.');	
	}

 else if(

	($project_data['project_owner'] != $_SESSION['user']['account_id'] &&					//false, true
	find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) == '') ||		 find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) != 0 && find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) != 1 && find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) != 2 && find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) != 3)
		{
			
			#echo $project_data['project_owner'].$_SESSION['user']['account_id'];
			#echo find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']);
			
			echo 'You are not allowed on this project.';
		
		}
	//print_r($rule);
	//print_r($inserting_resource);

else
{
	$tpl->set_var('id', getResourceID($inserting_resource));
        $tpl->set_var('display_resource_id', str_pad($inserting_resource['resource_id'], 6, '0', STR_PAD_LEFT));
        $tpl->set_var('entity', $inserting_resource['entity']);
        $tpl->set_var('created_on', substr($inserting_resource['created_on'], 0, 19));
        $tpl->set_var('created_by', find_user_loginID($inserting_resource['created_by']));
        $tpl->set_var('notes', $inserting_resource['notes']);
		


	//echo $_POST['upload_'.$inserting_resource['resource_id'].'_'.$rule['rule_id']];
	//echo $posted_upload;
	//echo $_POST[$posted_upload];
	if($_POST['insert_'.$inserting_resource['resource_id'].'_'.$rule['rule_id']] != '')
	{
		$value = $_POST['input_'.$inserting_resource['resource_id'].'_'.$rule['rule_id']];
		$notes = $_POST['text_'.$inserting_resource['resource_id'].'_'.$rule['rule_id']];
		$statvalue = $_POST['statvalue_'.$inserting_resource['resource_id'].'_'.$rule['rule_id']];
		//echo strlen($value);
		if($value !='')
		{
			$resource_id = $inserting_resource['resource_id'];
			$rule = get_rule_info($rule['rule_id']);
			if(object_is_resource($rule['object']) && !resource_found($rule['object'], $value))
			{
				$tpl->set_var('data_grid_insert_statements', render_resource_not_exists($resource_id, $rule, $value));			
			}
			else if(statement_exists($resource_id, $rule, $value))
			{
				$tpl->set_var('data_grid_insert_statements', render_statement_exists($resource_id, $rule, $value));			
			}
			else 
			{
				$statement_id = insert_statement($resource_id, $rule, $value, $notes);
				if($statement_id !='-1')
				$tpl->set_var('data_grid_insert_statements', render_inserted_statement($resource_id, $rule, $value, $statement_id));			
				//render_inserted_statement($tpl, $resource_id, $rule, $value, $statement_id);	
			}	
		}
		else
		{
			$tpl->set_var('data_grid_insert_statements', render_value_not_null($resource_id, $rule, $value));			
			//render_value_not_null($tpl, $resource_id, $rule, $value);	
		}
	}
	else if($_POST['upload_'.$inserting_resource['resource_id'].'_'.$rule['rule_id']] !='')
	{
		$notes = $_POST['text_'.$inserting_resource['resource_id'].'_'.$rule['rule_id']];
		
		$posted_upload = 'upload_input_'.$inserting_resource['resource_id'].'_'.$rule['rule_id'];
		
		$_FILES[$posted_upload]['name'];
		
		$file_name = $_FILES[$posted_upload]['name'];
				
		$mime_type = $_FILES[$posted_upload]['type'];
		
		$uploaded_file = $_FILES[$posted_upload]['tmp_name'];
		
#this bit will check if a folder for the project has been created, case not will create it, case yes will put the file into that folder
	#project_folder_exists will return true if a file exists for the project
		
		$maindir = S3DB_SERVER_ROOT.'/extras/'.$GLOBALS['s3db_info']['server']['db']['uploads_file'];

		if (project_folder_exists($_REQUEST['project_id']) =='')
		{
		
		
		$folder_code_name = random_string().'.project'.$_REQUEST['project_id'];

		$destinationfolder = $maindir."/".$folder_code_name;

		#create the folder for the project
		if(!file_exists($destinationfolder)) 
			{mkdir($destinationfolder, 0777);}
		
		$indexfile = $destinationfolder.'/index.php';
		if (file_exists($destinationfolder))
			{
		file_put_contents ($indexfile , 'This folder cannot be accessed');
		
			}
			
		}
	
		else 
		{
			$folder_code_name = project_folder_exists($_REQUEST['project_id']);
		}
	
	#here end the decision as to where the foldr will be and starts the process of moving the file

		list ($filename, $extension) = explode (".", $_FILES[$posted_upload]['name']);
		
		
		
		$file_in_folder =$folder_code_name.'/'.$filename.'_'.$_REQUEST['project_id'].'_'.$inserting_resource['resource_id'].'_'.$rule['rule_id'].'.'.$extension;
		
		$file_destination = $maindir."/".$file_in_folder;
			
		if($file_name =='')
		{
			$error_msg = "file name can not be empty";
			$tpl->set_var('data_grid_insert_statements', render_uploaded_file_error($error_msg));			
		}
		
		else
		{
			 if(filesize($uploaded_file) <= 0)
                	 {
                       		$error_msg = "size of file ".$file_name." can not be 0";
                        	$tpl->set_var('data_grid_insert_statements', render_uploaded_file_error($error_msg));
                	}
                	else
                	{
                       	 	move_uploaded_file($uploaded_file, $file_destination);
							
							#$Hyperlink = '<a href = '.$file_destination.'>';
							#$file_handle = fopen($uploaded_file, "r");
                        	#$file_contents = fread($file_handle, filesize($uploaded_file));
				
                        	//$base64_contents = base64_encode(gzcompress(base64_encode($file_contents)));
                        	#$base64_contents = base64_encode($file_contents);
				
                        	#fclose($file_handle);
                        
						$db = $_SESSION['db'];
                		#$sql = "insert into s3db_statement(project_id, resource_id, rule_id, value, notes, file_name, mime_type, created_on, created_by) values ('".$_REQUEST['project_id']."', '".$_REQUEST['resource_id']."', '".$_REQUEST['rule_id']."', '".$file_destination."', '".$notes."', '".$file_name."', '".$mime_type."', now(), '".$_SESSION['user']['account_id']."')";

						$sql = "insert into s3db_statement(project_id, resource_id, rule_id, value, notes, file_name, mime_type, created_on, created_by) values ('".$_REQUEST['project_id']."', '".$_REQUEST['resource_id']."', '".$_REQUEST['rule_id']."', '".$folder_code_name."', '".$notes."', '".$file_name."', '".$mime_type."', now(), '".$_SESSION['user']['account_id']."')";

                		//echo $sql;
                		$db->query($sql, __LINE__, __FILE__);
                		$statement_id =  $db->get_last_insert_id('s3db_statement', 'statement_id');

                        	if($statement_id !='-1')
                                	$tpl->set_var('data_grid_insert_statements', render_inserted_uploaded_file($resource_id, $rule, $file_name, $mime_type, $statement_id));
				else 
				{
					$tpl->set_var('data_grid_insert_statements', render_insert_statement('0', $inserting_resource['resource_id'], $rule));			
				}
			}
		}
	}
	elseif ($_POST['Hyperlink_'.$inserting_resource['resource_id'].'_'.$rule['rule_id']] !='')
	{	
		$value = $_POST['Hyperlink_ref_'.$inserting_resource['resource_id'].'_'.$rule['rule_id']];
		$ref_name= $_POST['Hyperlink_name_'.$inserting_resource['resource_id'].'_'.$rule['rule_id']];
		$statvalue = $_POST['statvalue_'.$inserting_resource['resource_id'].'_'.$rule['rule_id']];
		//echo strlen($value);
		if($value !='' && $value!='http://')
		{
			$resource_id = $inserting_resource['resource_id'];
			$rule = get_rule_info($rule['rule_id']);
			if(object_is_resource($rule['object']) && !resource_found($rule['object'], $value))
			{
				$tpl->set_var('data_grid_insert_statements', render_resource_not_exists($resource_id, $rule, $value));			
			}
			else if(statement_exists($resource_id, $rule, $value))
			{
				$tpl->set_var('data_grid_insert_statements', render_statement_exists($resource_id, $rule, $value));			
			}
			else
			{
				if ($ref_name!='') 	$value = urlencode('Hyperlink: <a href='.$value.'>'.$ref_name.'</a>');
				else 	$value = urlencode('Hyperlink: <a href='.$value.'>'.$value.'</a>');
				$statement_id = insert_statement($resource_id, $rule, $value, $notes);
				if($statement_id !='-1')
				$tpl->set_var('data_grid_insert_statements', render_inserted_statement($resource_id, $rule, $value, $statement_id));			
				//render_inserted_statement($tpl, $resource_id, $rule, $value, $statement_id);	
			}	
		}
		else
		{
			$tpl->set_var('data_grid_insert_statements', render_value_not_null($resource_id, $rule, $value));			
			//render_value_not_null($tpl, $resource_id, $rule, $value);	
		}
	
	
	}	
	
	else
	{
		//echo " I am here";
		$tpl->set_var('data_grid_insert_statements', render_insert_statement('0', $inserting_resource['resource_id'], $rule));			
		//render_insert_statement($tpl, '0', $inserting_resource['resource_id'], $rule);
	}
}
	$tpl->set_block('statement', 'insert_statements', '_statement');
       	$tpl->parse('_output', 'insert_statements', True);
        $tpl->pfp('out','_output');

	function statement_exists($resource_id, $rule, $value)
	{
		$db = $_SESSION['db'];

		$sql = "select statement_id from s3db_statement where project_id='".$_REQUEST['project_id']."' and resource_id='".$resource_id."' and rule_id='".$rule['rule_id']."' and value='".$value."'";
		//echo $sql;
		$db->query($sql, __LINE__, __FILE__);
		if($db->next_record())
			return True;
		else		
			return False;
	}
	
	function insert_statement($resource_id, $rule, $value, $notes)
	{
		$db = $_SESSION['db'];

		$sql = "insert into s3db_statement (project_id, resource_id, rule_id, value, notes, created_on, created_by) values ('".$_REQUEST['project_id']."', '".$resource_id."','".$rule['rule_id']."','".$value."','".$notes."', now(),'".$_SESSION['user']['account_id']."')";
		$db->query($sql, __LINE__, __FILE__);
		return $db->get_last_insert_id('s3db_statement', 'statement_id');
	}
	
	function render_statement_exists($resource_id, $rule, $value)
	{
		$message = sprintf("\n%s\n", '<table width="100%"><tr><td>');	
		$message .= sprintf("%s\n", '	<font color="red">Statement already exists</font>');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	<tr><td>');
		$message .= sprintf("%s\n", '      <ol>');
		$message .= sprintf("%s\n", '      	<li><i>Resource</i> <b>'.$rule['subject'].'</b> ID #'.str_pad($resource_id, 6, '0', STR_PAD_LEFT).' found</li>');
		$message .= sprintf("%s\n", '      	<li><i>Rule</i> <b>'.$rule['subject'].' + '.$rule['verb'].' + '.$rule['object'].'</b> found</li>');
		$message .= sprintf("%s\n", '      	<li>But <i>Statement</i> <b>'.$rule['subject'].' | '.$rule['verb'].' | '.$rule['object'].' [ '.urldecode($value).' ]</b> for the above resource already exists</li>');
		$message .= sprintf("%s\n", '      </ol>');
		$message .= sprintf("%s\n", '	<tr><td>');
		$message .= sprintf("%s\n", '		<br /><input type="button" value="Try again" onClick="window.history.go(-1)">');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	</table>');
		return $message;
	}

	function render_resource_not_exists($resource_id, $rule, $value)
	{
		$message = sprintf("\n%s\n", '<table width="100%"><tr><td>');	
		$message .= sprintf("%s\n", '	<font color="red">Resource does not exist</font>');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	<tr><td>');
		$message .= sprintf("%s\n", '      <ol>');
		$message .= sprintf("%s\n", '      	<li><i>Resource</i> <b>'.$rule['subject'].'</b> ID #'.str_pad($resource_id, 6, '0', STR_PAD_LEFT).' found</li>');
		$message .= sprintf("%s\n", '      	<li><i>Rule</i> <b>'.$rule['subject'].' + '.$rule['verb'].' + '.$rule['object'].'</b> found</li>');
                $message .= sprintf("%s\n", '           <li><i><b>'.$rule['object'].'</b> is resource</li>');
		$message .= sprintf("%s\n", '      	<li>But <i>Resource</i> <b>'.$rule['object'].'</b> ( UID: <b>'.$value.'</b> ) does not exist</li>');
		$message .= sprintf("%s\n", '      </ol>');
		$message .= sprintf("%s\n", '	<tr><td>');
		$message .= sprintf("%s\n", '		<br /><input type="button" value="Try again" onClick="window.history.go(-1)">');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	</table>');
		return $message;
	}

	function render_value_not_null($resource_id, $rule, $value)
	{
		$message = sprintf("\n%s\n", '<table width="100%"><tr><td>');	
		$message .= sprintf("%s\n", '	<font color="red">Value can not be empty</font>');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	<tr><td>');
		/*print_r($_SERVER['HTTP_USER_AGENT']);
		if(strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE'))
			$message .= sprintf("%s\n", '		<br /><input type="button" value="Try again" onClick="window.history.go(-2)">');
		else
*/
		$message .= sprintf("%s\n", '		<br /><input type="button" value="Try again" onClick="window.history.go(-1)">');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	</table>');
		return $message;
		//$handle->set_var('data_grid_insert_statements', $message);			
	}

	function render_inserted_statement($resource_id, $rule, $value, $statement_id)
	{
		$message = sprintf("\n%s\n", '<table width="100%"><tr><td>');	
		$message .= sprintf("%s\n", '	<font color="red">Statement inserted</font>');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	<tr><td>');
		$message .= sprintf("%s\n", '      <ol>');
		$message .= sprintf("%s\n", '      	<li><i>Resource</i> <b>'.$rule['subject'].'</b> ID #'.str_pad($resource_id, 6, '0', STR_PAD_LEFT).' found</li>');
		$message .= sprintf("%s\n", '      	<li><i>Rule</i> <b>'.$rule['subject'].' + '.$rule['verb'].' + '.$rule['object'].'</b> found</li>');
		if(object_is_resource($rule['object']) && resource_found($rule['object'], $value))
		$message .= sprintf("%s\n", '      	<li><i>Found Resource </i> <b>'.$rule['object'].'</b> ( UID: <b>'.$value.'</b> )</li>');
		$message .= sprintf("%s\n", '      	<li><i>Statement</i> <b>'.$rule['subject'].' | '.$rule['verb'].' | '.$rule['object'].' [ '.urldecode($value).' ]</b> for the above resource inserted</li>');
		$message .= sprintf("%s\n", '      	<li>Statement ID:  <b>'.$statement_id.'</b></li>');
		$message .= sprintf("%s\n", '      </ol>');
		$message .= sprintf("%s\n", '	<tr><td>');
		$message .= sprintf("%s\n", '		<br /><input type="button" value="Insert Another" onClick="opener.window.location.reload(); window.history.go(-1); return false;">');
		$message .= sprintf("%s\n", '		&nbsp;&nbsp;<input type="button" value="Close Window" onClick="opener.window.location.reload(); self.close();return false;">');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	</table>');
		return $message;
		//$handle->set_var('data_grid_insert_statements', $message);			
	}
	
	function render_uploaded_file_error($error_msg)
	{
		$message = sprintf("\n%s\n", '<table width="100%"><tr><td>');	
		$message .= sprintf("%s\n", '	<font color="red">'.$error_msg.'</font>');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	<tr><td>');
		$message .= sprintf("%s\n", '		<br /><input type="button" value="Upload Another File" onClick="opener.window.location.reload(); window.history.go(-1); return false;">');
		$message .= sprintf("%s\n", '		&nbsp;&nbsp;<input type="button" value="Close Window" onClick="opener.window.location.reload(); self.close();return false;">');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	</table>');
		return $message;

	}

	function render_inserted_uploaded_file($resource_id, $rule, $file_name, $mime_type, $statement_id)
	{
		$message = sprintf("\n%s\n", '<table width="100%"><tr><td>');	
		$message .= sprintf("%s\n", '	<font color="red">File uploaded</font>');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	<tr><td>');
		$message .= sprintf("%s\n", '      <ol>');
		$message .= sprintf("%s\n", '      	<li><i>Resource</i> <b>'.$rule['subject'].'</b> ID #'.str_pad($resource_id, 6, '0', STR_PAD_LEFT).' found</li>');
		$message .= sprintf("%s\n", '      	<li><i>Rule</i> <b>'.$rule['subject'].' + '.$rule['verb'].' + '.$rule['object'].'</b> found</li>');
		//if(object_is_resource($rule['object']) && resource_found($rule['object'], $value))
		//$message .= sprintf("%s\n", '      	<li><i>Found Resource </i> <b>'.$rule['object'].'</b> ( UID: <b>'.$value.'</b> )</li>');
		$message .= sprintf("%s\n", '      	<li><i>Statement</i> <b>'.$rule['subject'].' | '.$rule['verb'].' | '.$rule['object'].' [ File: <a href=download.php{get_proj_id}{get_res_id}&resource_id='.$_REQUEST['resource_id'].'&rule_id='.$_REQUEST['rule_id'].'&statement_id='.$statement_id.'>'.$file_name.'<a/> ]</b> for the above resource inserted</li>');
		$message .= sprintf("%s\n", '      	<li>Statement ID:  <b>'.$statement_id.'</b></li>');
		$message .= sprintf("%s\n", '      </ol>');
		$message .= sprintf("%s\n", '	<tr><td>');
		$message .= sprintf("%s\n", '		<br /><input type="button" value="Upload Another File" onClick="opener.window.location.reload(); window.history.go(-1); return false;">');
		$message .= sprintf("%s\n", '		&nbsp;&nbsp;<input type="button" value="Close Window" onClick="opener.window.location.reload(); self.close();return false;">');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	</td></tr>');
		$message .= sprintf("%s\n", '	</table>');
		return $message;
		//$handle->set_var('data_grid_insert_statements', $message);			
	}

	function get_resource_info($id)
	{
		$db= $_SESSION['db'];
		$sql ="select * from s3db_resource where resource_id='".$id."'";
		$db->query($sql, __LINE__, __FILE__);
		while($db->next_record())
		{
			$resource = Array('resource_id'=>$db->f('resource_id'),
					 'project_id'=>$db->f('project_id'),
					//'owner'=>$db->f('owner'),
					'iid'=>$db->f('iid'),
					'entity'=>$db->f('entity'),
					'notes'=>$db->f('notes'),
					'created_on'=>$db->f('created_on'),
					'created_by'=>$db->f('created_by'),	
					'modified_on'=>$db->f('modified_on'),
					'modified_by'=>$db->f('modified_by'));
		}
		return $resource;
	}	
	
	function get_user_short_info($id)
	{
		$db= $_SESSION['db'];
		$sql ="select * from s3db_account where account_id='".$id."'";
		$db->query($sql, __LINE__, __FILE__);
		if($db->next_record())
		{
			$user = Array('account_id'=>$db->f('account_id'),
					'account_lid'=>$db->f('account_lid'),
					'account_uname'=>$db->f('account_uname'));
		}
		return $user;
	}
	                                                                                             
	function get_distinct_statements($resource_id)         {
                $db = $_SESSION['db'];
                $sql = "select distinct subject, verb, object from s3db_statement where resource_id='".$resource_id."' order by verb, object";
                //echo $sql;
                $db->query($sql, __LINE__, __FILE__);
                while($db->next_record())
                {
                        $distinct_stats[] = Array('subject'=>$db->f('subject'),
                                                  'verb'=>$db->f('verb'),
                                                  'object'=>$db->f('object'));                 }
                                                                                                                                                             
                return $distinct_stats;
        }
	
	function render_resource($handle, $inserting_resource)
	{
		//print_r($inserting_resource);
		$handle->set_var('id', getResourceID($inserting_resource));
		$handle->set_var('display_resource_id', str_pad($inserting_resource['resource_id'], 6, '0', STR_PAD_LEFT));
		$handle->set_var('entity', $inserting_resource['entity']);
		$handle->set_var('created_on', substr($inserting_resource['created_on'], 0, 19));
		$handle->set_var('created_by', find_user_loginID($inserting_resource['created_by']));
		$handle->set_var('notes', $inserting_resource['notes']);
	}	
	 function getResourceID($resource)
        {global $resource_info, $project_info;
		//print_r($resource);
                $acl = find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']);
                $result =  str_pad($resource['resource_id'], 6, '0', STR_PAD_LEFT).'<br />';
		//echo $result;
                if($_SESSION['user']['account_id'] == $project_info['owner'] || $acl =='3' ||$acl =='2' ||$resource['created_by']==$_SESSION['user']['account_id'])
                        $result .= getEditLink($resource['resource_id']). '&nbsp;&nbsp;'. getDeleteLink($resource['resource_id']);
                return $result;
        }
                                                                                                                                                             
        function getEditLink($resource)
        {
                $res = '<a href="#" onClick="window.open(\'../resource/editresource.php{get_proj_id}{get_res_id}&resource_id='.$resource.'\', \'editresource_'.$resource.'\', \'width=450, height=450, location=no, titlebar=no, scrollbars=yes, resizable=yes\')" title="Edit resource '.$resource.' )">Edit</a>';
                return $res;
        }
                                                                                                                                                             
        function getDeleteLink($resource)
        {
                $res = '<a href="#" onClick="window.open(\'../resource/deleteresource.php{get_proj_id}{get_res_id}&resource_id='.$resource.'\', \'deleteresource_'.$resource.'\', \'width=450, height=450, location=no, titlebar=no, scrollbars=yes, resizable=yes\')" title="Delete resource '.$resource.'">Delete</a>';
                return $res;
        }
        function printCreatedOn($params)
        {
                extract($params);
                return substr($record['created_on'], 0, 19);
        }
        function printEntity($params)
        {
                extract($params);
                return $record['entity'];
        }
        function printResourceNotes($params)
        {
                extract($params);
                return $record['notes'];
        }
	
	function render_insert_statement($index, $resource_id, $rule)
	{
		//echo $resource_id;
		 $_SESSION['current_color']='0';
                $_SESSION['previous_verb']='';
	
		 $verb = $rule['verb'];
                 $rule_notes = preg_replace('/\(.*\)/', '', $rule['notes']);

		$stats ="";
		$stat = sprintf("\n%s\n", '<table width="100%"><tr bgcolor="lightyellow"><td colspan="3">');	
		//$stat .= sprintf("%s\n", ($index+1).'. <font color="brown" size="2"> [ '.$rule['subject'].' | '.$rule['verb'].' | '.$rule['object'].' ]</font><br />&nbsp;&nbsp;&nbsp;&nbsp;');
		$stat .= sprintf("%s\n", ($index+1).'. [ '.printVerb($verb).' | '.$rule['object'].' ]</font><br />&nbsp;&nbsp;&nbsp;&nbsp;');
		//$stat .= sprintf("%s\n", '</td></tr>');
		//$stat .= sprintf("%s\n", '<tr><td>');
		//$rule = get_rule($subject, $verb, $object);
		//print_r($rule);
		$stat .= sprintf("%s\n", '<font size-=2 color="dodgerblue">'.$rule['notes'].'</font>');
		$stat .= sprintf("%s\n", '</td></tr>');
		$stat .= sprintf("%s\n", '<tr><td><b><font color="navy" size="2">&nbsp;&nbsp;Value</font></b></td><td><b><font color="navy" size="2">&nbsp;&nbsp;Notes</font></b></td><td>&nbsp;</td>');
		if(object_is_resource($rule['object']))
		{
			$stat .= sprintf("%s\n", '<tr><td valign="top">');
			$peek ='<input type="button" name="input_'.$resource_id.'_'.$rule['rule_id'].'existvalues" value="Peek" onClick="window.open(\'existuid.php{get_proj_id}{get_res_id}&rule_id='.$rule['rule_id'].'&name=input_'.$resource_id.'_'.$rule['rule_id'].'\', \'_blank\', \'width=500, height=500, location=no, titlebar=no, scrollbars=yes, resizable=yes\')"><br />';
			$stat .= sprintf("%s\n", '&nbsp;&nbsp;<textarea type="text" style="background: lightyellow" name="input_'.$resource_id.'_'.$rule['rule_id'].'" cols="20"></textarea>&nbsp;&nbsp;'.$peek.'</td>');
			$stat .= sprintf("%s\n", '<td valign="top"><textarea style="background: lightyellow" name="text_'.$resource_id.'_'.$rule['rule_id'].'" rows="2" cols="20"></textarea></td>');
			
			$stat .= sprintf("%s\n", '<td valign="top"><input type="submit" name="insert_'.$resource_id.'_'.$rule['rule_id'].'" value="Insert">');
					
			$stat .= sprintf("%s\n", '</td></tr>');
			$stat .= sprintf("%s\n", '<tr><td valign="top" colspan="3">');
			#$stat .= sprintf("%s\n", '<br />&nbsp;&nbsp;<input name="Hyperlink_input_'.$resource_id.'_'.$rule['rule_id'].'" value="http://" type="text" />&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="Hyperlink_'.$resource_id.'_'.$rule['rule_id'].'" value="Add Hyperlink" /><BR><BR> ');	
			
			$stat .= sprintf("%s\n", '<br />&nbsp;&nbsp;<input name="upload_input_'.$resource_id.'_'.$rule['rule_id'].'" type="file" />&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="upload_'.$resource_id.'_'.$rule['rule_id'].'" value="Upload File" /> ');
			
			
			$stat .= sprintf("%s\n", '</td></tr>');
		}
		else
		{
			$stat .= sprintf("%s\n", '<tr><td valign="top">');
			$stat .= sprintf("%s\n", '&nbsp;&nbsp;<textarea type="text" style="background: lightyellow" name="input_'.$resource_id.'_'.$rule['rule_id'].'" cols="20"></textarea></td>');
			$stat .= sprintf("%s\n", '<td valign="top"><textarea style="background: lightyellow" name="text_'.$resource_id.'_'.$rule['rule_id'].'" rows="2" cols="20"></textarea></td>');
			$stat .= sprintf("%s\n", '<td valign="top"><input type="submit" name="insert_'.$resource_id.'_'.$rule['rule_id'].'" value="Insert">');
			$stat .= sprintf("%s\n", '</td></tr>');
			$stat .= sprintf("%s\n", '<tr><td valign="top" colspan="3">');
			$stat .= sprintf("%s\n", '<br />&nbsp;&nbsp;<input name="Hyperlink_ref_'.$resource_id.'_'.$rule['rule_id'].'" value = "http://" type="text" /><input type = "text" name="Hyperlink_name_'.$resource_id.'_'.$rule['rule_id'].'">&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="Hyperlink_'.$resource_id.'_'.$rule['rule_id'].'" value="Add Hyperlink" /><BR><BR> ');
			$stat .= sprintf("%s\n", '<br />&nbsp;&nbsp;<input name="upload_input_'.$resource_id.'_'.$rule['rule_id'].'" type="file" />&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="upload_'.$resource_id.'_'.$rule['rule_id'].'" value="Upload File" /> ');

		#i'll leave this for later	$stat .= sprintf("%s\n", '<center><IFRAME SRC="progress_bar/progressbar.php" SCROLLING="no" frameborder="0"></IFRAME></center>');
			
			$stat .= sprintf("%s\n", '</td></tr>');

		}
		$stat .=sprintf("%s\n", '</table>');	
		$stats .= $stat;
		return $stats;
		//$handle->set_var('data_grid_insert_statements', $stats);			

	}
	
	   function printVerb($verb)
        {
                if($_SESSION['previous_verb'] =='')
                        $_SESSION['previous_verb'] = $verb;
                else if(!strsimilar($_SESSION['previous_verb'], $verb))
                {
                        $_SESSION['previous_verb'] = $verb;
                        $_SESSION['current_color'] = intVal($_SESSION['current_color']) + 1;
                }
                switch(intVal($_SESSION['current_color'])%3)
                {
                        case 0:
                                return '<font color="red">'.$verb.'</font>';
                        case 1:
                                return '<font color="green">'.$verb.'</font>';
                        case 2:
                                return '<font color="blue">'.$verb.'</font>';
                }
        }

	function object_is_resource($object)
	{
		$db = $_SESSION['db'];
		$sql = "select entity from s3db_resource where entity='".$object."' and project_id='".$_REQUEST['project_id']."'";
		$db->query($sql, __LINE__, __FILE__);
		if($db->next_record())
			return True;
		else	
			return False;
	}

	function resource_found($object, $value)
	{
		$db = $_SESSION['db'];
		$sql = "select entity from s3db_resource where entity='".$object."' and resource_id='".$value."' and project_id='".$_REQUEST['project_id']."'";
		$db->query($sql, __LINE__, __FILE__);
		if($db->next_record())
			return True;
		else	
			return False;

	}
/*	
	function render_statements($handle, $inserting_resource, $rule)
	{
		$distinct_stats = get_distinct_statements($inserting_resource['resource_id']);
		//print_r($distinct_stats);
		if(count($distinct_stats) > 0)
		{
			$stats ="";
			foreach($distinct_stats as $i => $value)
			{
				$subject = $distinct_stats[$i]['subject'];
				$verb = $distinct_stats[$i]['verb'];
				$object = $distinct_stats[$i]['object'];
				$index = $i;
				$stat = sprintf("\n%s\n", '<table width="100%"><tr><td>');	
				$stat .= sprintf("%s\n", ($index+1).'.<font color="brown" size="2"> [ '.$subject.' | '.$verb.' | '.$object.' ]</font><br />&nbsp;&nbsp;&nbsp;&nbsp;');
				$stat .= sprintf("%s\n", '</td></tr>');
				$stat .= sprintf("%s\n", '<tr><td>');
				$stat .= sprintf("%s\n", '<input type="text" style="background: lightyellow" name="insert" value="">&nbsp;&nbsp;<input type="submit" name="insert" value="Insert">');
				$stat .= sprintf("%s\n", '</td></tr>');
				//$rule = get_rule($subject, $verb, $object);
				$stat .= sprintf("$s\n", '<font color="dodgerblue">'.$rule['notes'].'</font>');
				$stat .=sprintf("%s\n", '</table>');	
				$stats .= $stat;
				//echo $stat;	
			}
		}
		//echo $stats;	
		$handle->set_var('data_grid_insert_statements', $stats);			
	}
*/
	function get_rule_info($rule_id)
        {
                $db = $_SESSION['db'];
                $sql ="select rule_id, subject, verb, object, notes from s3db_rule where rule_id='".$rule_id."'";
                $db->query($sql, __LINE__, __FILE__);
                if($db->next_record())
		{
                	$rule = Array('rule_id'=>$db->f('rule_id'),
					'subject'=>$db->f('subject'),
					'verb'=>$db->f('verb'),
					'notes'=>$db->f('notes'),
					'object'=>$db->f('object'));
		}
		return $rule;
        }

	function get_exist_stats($resource_id, $subject, $verb, $object)
	{
		$db = $_SESSION['db'];
		$sql = "select statement_id, value, created_on, created_by, notes from s3db_statement where resource_id='".$resource_id."' and subject='".$subject."' and verb='".$verb."' and object='".$object."'";
		$db->query($sql, __LINE__, __FILE__);
		while($db->next_record())
		{
			$sub_stats[] = Array('value'=>$db->f('value'),
					'created_on'=>$db->f('created_on'),
					'statement_id'=>$db->f('statement_id'),
					'created_by'=>$db->f('created_by'),
					'notes'=>$db->f('notes'));
		}
		return $sub_stats;	
	}
	
	function render_inputbox($stat)
	{
		
	}	
	 function render_substatements($datasource, $order, $direction)
        {
                //print_r($datasource);
                $orderBy = $order;
                $dir = $direction;

                // Create the DataGrid, bind it's Data Source
                $dg =& new Structures_DataGrid(); // Display 20 per page
                $dg->bind($datasource);
                // Define DataGrid's columns
		
                $dg->addColumn(new Structures_DataGrid_Column('Value', null, null, array('width'=>'30%', 'align'=>'left', 'valign'=>'top'), null, 'printValue()'));
                $dg->addColumn(new Structures_DataGrid_Column('Created On', null, null, array('width'=>'15%', 'align'=>'left', 'valign'=>'top'), null, 'printCreatedOn()'));
                $dg->addColumn(new Structures_DataGrid_Column('Created By', null, null, array('width'=>'15%', 'align'=>'left', 'valign'=>'top'), null, 'printCreatedBy()'));
                $dg->addColumn(new Structures_DataGrid_Column('Notes', null, null, array('width'=>'20%', 'align'=>'left', 'valign'=>'top'), null, 'printStatementNotes()'));
                $dg->addColumn(new Structures_DataGrid_Column(null, null, null, array('align'=>'left', 'valign'=>'top'), null, 'printAction()'));
/*
                $dg->addColumn(new Structures_DataGrid_Column(null, null, null, array('width'=>'30%', 'align'=>'left', 'valign'=>'top'), null, 'printValue()'));
                $dg->addColumn(new Structures_DataGrid_Column(null, null, null, array('width'=>'15%', 'align'=>'left', 'valign'=>'top'), null, 'printCreatedOn()'));
                $dg->addColumn(new Structures_DataGrid_Column(null, null, null, array('width'=>'15%', 'align'=>'left', 'valign'=>'top'), null, 'printCreatedBy()'));
                $dg->addColumn(new Structures_DataGrid_Column(null, null, null, array('width'=>'20%', 'align'=>'left', 'valign'=>'top'), null, 'printStatementNotes()'));
                $dg->addColumn(new Structures_DataGrid_Column(null, null, null, array('align'=>'left', 'valign'=>'top'), null, 'printAction()'));
 */               // Define the Look and Feel
                //$dg->renderer->setUseHeader(false);
                //$dg->renderer->setTableHeaderAttributes(array('bgcolor'=>'#FFCCFF'));
                $dg->renderer->setTableHeaderAttributes(array('bgcolor'=>'lightyellow'));
                $dg->renderer->setTableEvenRowAttributes(array('bgcolor'=>'#FFFFFF', 'valign'=>'top'));
                $dg->renderer->setTableOddRowAttributes(array('bgcolor'=>'#EEEEEE', 'valign'=>'top'));
                $dg->renderer->setTableAttribute('width', '100%');
                $dg->renderer->setTableAttribute('align', 'left');
                $dg->renderer->setTableAttribute('valign', 'top');
                $dg->renderer->setTableAttribute('border', '0px');
                $dg->renderer->setTableAttribute('cellspacing', '4');
                $dg->renderer->setTableAttribute('cellpadding', '4');
                $dg->renderer->setTableAttribute('class', 'datagrid');
                //$dg->renderer->setOddRowAttribute('valign', 'top');
                //$dg->renderer->setEvenRowAttribute('valign', 'top');
                $dg->renderer->sortIconASC = '&uarr;';
                $dg->renderer->sortIconDESC = '&darr;';
                $htmloutput =  $dg->render();
                $htmloutput .= $dg->renderer->getPaging();
                return $htmloutput;
        }
	 function printAction($params)
        {global $resource_info, $project_info;
                extract($params);
                $acl = find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']);
               if($_SESSION['user']['account_id'] == $project_info['owner'] || $acl =='3' ||$acl =='2' ||$record['created_by']==$_SESSION['user']['account_id'])
                    $result .= printEditStatementLink($params). '&nbsp;&nbsp;'. printDeleteStatementLink($params);
                return $result; 
       }
	function printEditStatementLink($params)
        {
                extract($params);
                $res = '<a href="#" onClick="window.open(\'editstatement.php{get_proj_id}{get_res_id}&statement_id='.$record['statement_id'].'\', \'editstatement_'.$record['statement_id'].'\', \'width=450, height=600, location=no, titlebar=no, scrollbars=yes, resizable=yes\')" title="Edit statement '.$record['statement_id'].'">Edit</a>';
                return $res;
        }

        function printDeleteStatementLink($params)
        {
                extract($params);
                $res = '<a href="#" onClick="window.open(\'deletestatement.php{get_proj_id}{get_res_id}&statement_id='.$record['statement_id'].'\', \'deletestatement_'.$record['statement_id'].'\', \'width=450, height=600, location=no, titlebar=no, scrollbars=yes, resizable=yes\')" title="Delete statement '.$record['statement_id'].'">Delete</a>';
                //$res = '<a href="#" onClick="window.open(\'deleteresource.php?resource_id='.$record['resource_id'].'\', \'deleteresource\', \'width=450, height=400, location=no, titlebar=no, scrollbar=yes, resizable=yes\')" title="Delete resource '.$record['resource_id'].' ( '.$record['entity'].' )">Delete</a>';
                return $res;
        }
	
	 function printValue($params)
        {
                extract($params);
		return $record['value'];
	}
	
	/* function printCreatedOn($params)
        {
                extract($params);
		return $record['created_on'];
	}
	*/	
	 function printCreatedBy($params)
        {
                extract($params);
		return $record['created_by'];
	}
	 function printStatementNotes($params)
        {
                extract($params);
		return $record['notes'];
	}

		function random_string()
	{
	  $acceptedChars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYS0123456789';
  $max = strlen($acceptedChars)-1;
  $random = null;
  for($i=0; $i < 15; $i++) {
   $random .= $acceptedChars{mt_rand(0, $max)};
  }
  return $random;
	
	}

	function project_folder_exists ($project_id)

	{
		$maindir = S3DB_SERVER_ROOT.'/extras/'.$GLOBALS['s3db_info']['server']['db']['uploads_file'];
			if (is_dir($maindir))
			{$handle = opendir($maindir);
			
			 while (false !== ($file = readdir($handle))) 
				 {
				 
				
				 $folder_list[] .= $file;

					 
			   
				}
			 #check if a folder has already been created for the project
			 foreach ($folder_list as $folder)
				{
				 list($codename, $project) = explode('.', $folder);
				#echo $codename.'<BR>';
				$project_folder =  $codename.'.project'.$_REQUEST['project_id'];
				#echo '<BR>'.$project_folder;
			 	if (file_exists($maindir."/".$project_folder)) {return $project_folder;}
				
				}
				#closedir($handle);
		
				}
		}
	
	function get_project_info($project_id)
	{
		$db = $_SESSION['db'];
		$sql = "select * from s3db_project where project_id='".$project_id."'";
		$db->query($sql, __LINE__, __FILE__);
		if($db->next_record())
		{
			$project_info=Array('project_id'=>$db->f('project_id'),
					   'project_name'=>$db->f('project_name'),
					   'project_owner'=>$db->f('project_owner'),
					   'project_description'=>$db->f('project_description'),
					   'project_status'=>$db->f('project_status'),
					   'created_on'=>$db->f('created_on'),
					   'created_by'=>$db->f('created_by'),
					   'modified_on'=>$db->f('modified_on'),
					   'modified_by'=>$db->f('modified_by'));

		} 
		return $project_info;
	}
	

	
?>
