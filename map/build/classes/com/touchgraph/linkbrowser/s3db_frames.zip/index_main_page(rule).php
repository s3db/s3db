<?php
	/***************************************************************************\
        * S3DB                                                                     *
        * http://www.s3db.org                                                      *
        * Written by Chuming Chen <chumingchen@gmail.com>                          *
        * ------------------------------------------------------------------------ *
        * This program is free software; you can redistribute it and/or modify it  *
        * under the terms of the GNU General Public License as published by the    *
        * Free Software Foundation; either version 2 of the License, or (at your   *
        * option) any later version.                                               *
        * See http://www.gnu.org/copyleft/gpl.html for detail                      *
        \**************************************************************************/
		/**************************************************************************
		/																		   /
		/Modified by Helena Futscher de Deus  <helenadeus@gmail.com>			   /
		/																		   /
		***************************************************************************/


	if(file_exists('../config.inc.php'))
	{
		include('../config.inc.php');
	}
	else
	{
		Header('Location: index.php');
		exit;
	}
	
	
	include(S3DB_SERVER_ROOT.'/header_main_page.inc.php');
	


	if($_GET['created_on']!='')
	{
		$sortorder = 'created_on';
	}
	else
	{
		$sortorder = 'rule_id';

	}
	
	#if ($_POST['newrule']!='') echo '<body onload="parent.ProjectsFrames.location.href = \'../frames/ProjectsFrames.php?project_id='.$_REQUEST['project_id'].'\'">';
	

	if($_GET['page']!='' )
        $_SESSION['current_page'] = $_GET['page'];
    if(!empty($_GET['num_per_page']))
        {
		$num_per_page = $_GET['num_per_page'];
                //$tpl->set_var('num_per_page'.$num_per_page);
        	$tpl->set_var('selected_'.$num_per_page, 'selected');
                $_SESSION['num_per_page'] = $num_per_page;
        }
	else 
        	$tpl->set_var('selected_'.$_SESSION['num_per_page'], 'selected');


	if(!empty($_GET['rule_id']))
        {
                $edited_rule = get_rule_info($_GET['rule_id']);
                $tpl->set_var('rule_id', $_GET['rule_id']);
        }
        else
        {
                $edited_rule = get_rule_info($_POST['rule_id']);
                $tpl->set_var('rule_id', $_POST['rule_id']);
        }
	
	$tpl->set_file(array('rule'=> 'rule_main_page.tpl'));
	$tpl->set_var('image_path', '..');
	$tpl->set_var('section_num', '3');
	$tpl->set_var('action_url', 'index_main_page.php{get_proj_id}{get_res_id}');
	$tpl->set_var('website_title',  $GLOBALS['s3db_info']['server']['site_title'].' - rules');
	$tpl->set_block('rule', 'top', '_rule');
        $tpl->fp('_output', 'top', True);
	
	$project_data = get_project_info($_REQUEST['project_id']);
	
	if($resource_info == '')
	{
		$tpl->set_var('message', 'You are not working with any resource yet. Please select a working <a href="../resource/index_main_page.php{get_proj_id}">resource</a> by clicking the <b>Name</b> of resource.');	
	}
	
	

	if ($_REQUEST['project_id'] == '')
	{
		$tpl->set_var('message', 'You are not working with any project yet. Please select a working <a href="../project/index.php">project</a> by clicking the <b>Name</b> of project.');	
	}

 else if(

	($project_data['project_owner'] != $_SESSION['user']['account_id'] &&					//false, true
	find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) == '') ||		 find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) != 0 && find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) != 1 && find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) != 2 && find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']) != 3)
		{
			
			#echo $project_data['project_owner'].$_SESSION['user']['account_id'];
			#echo find_user_acl($_SESSION['user']['account_id'], $_REQUEST['project_id']);
			
			$tpl->set_var('message', 'You are not allowed on this project.');
		
		}
	else
	{	
		$tpl->set_var('current_stage', 'Project: <b>'.$project_info['name'].'</b>&nbsp;&nbsp; | &nbsp;&nbsp; Resource: <b>'.$resource_info['entity'].'</b>');
		$tpl->set_var('content_width', '100%');
		 $tpl->set_var('resources_list', create_resources_list());
		//echo $_SESSION['working_project'];
		$rules = list_rules();
		 $tpl->set_var('available_rules', count($rules));
		if($record['owner'] == $_SESSION['user']['account_lid'] || $project_info['owner'] == $_SESSION['user']['account_id'] || get_permissions() == '3')
		 $tpl->set_var('delete_button', '<input type="submit" name="delete_resource" value="Delete Resource '.$resource_info['entity'].'">{hidden_project}{hidden_entity}');
			
		//print_r($rules);
		$tpl->set_var('manager', 'Rule Manager');
		if(count($rules) > 0)
		{	
			//$tpl->set_block('rule', 'middle', '_rule');
        		//$tpl->fp('_output', 'middle', True);
			if($project_info['owner'] == $_SESSION['user']['account_id'] || get_permissions() == '3')
			{
				$tpl->set_var('data_grid',render_rules($rules, $sortorder,'ASC' ));
				$tpl->set_block('rule', 'edit_rule', '_rule');
       				$tpl->fp('_output', 'edit_rule', True);
			}
			else	
			{
				$tpl->set_var('data_grid',render_rules($rules, $sortorder,'ASC' ));
				$tpl->set_block('rule', 'view_rule', '_rule');
       				$tpl->fp('_output', 'view_rule', True);
				//$tpl->set_var('message', 'You do not have permission to create rule.');	
			}
		}
                else 
		{
			if($project_info['owner'] == $_SESSION['user']['account_id'] || get_permissions() == '3')
			{
				$tpl->set_block('rule', 'edit_rule', '_rule');
       				$tpl->fp('_output', 'edit_rule', True);
				$tpl->set_var('message', 'You do not have any rule yet. Please create a new rule first.');	
			}
			else
				$tpl->set_var('message', 'You do not have any rule yet. You also do not have permission to create rule.');	
		}
		//echo get_project_owner();
		if($_GET['action'] == 'edit')
		{
			$rule = get_rule_info($_GET['rule_id']);
			$tpl->set_var('rule_id',$rule['rule_id']);
			$tpl->set_var('action_name','editrule'); 
			$tpl->set_var('action_value','Update'); 
			$tpl->set_var('subject', $rule['subject']); 
			$tpl->set_var('verb', '<input name="verb" style="background: lightyellow" value="'.$rule['verb'].'" size="10"></td>'); 
			$tpl->set_var('object', '<input name="object" style="background: lightyellow" value="'.$rule['object'].'" size="10"></td>'); 
			if($rule['verb'] == 'has UID')
				$tpl->set_var('verb', 'has UID'); 
			if($rule['object'] == 'UID')
				$tpl->set_var('object', 'UID'); 
			
			$tpl->set_var('notes', $rule['notes']); 
			$tpl->set_var('owner', find_user_loginID($rule['created_by'])); 
			$tpl->set_var('created_on', $rule['created_on']); 
			$tpl->set_var('displayed_rule_id', $rule['rule_id']); 
			$tpl->set_var('displayed_resource_id', $rule['resource_id']); 

			$tpl->set_var('edit_message', 'Update Rule');

		}
		else if($_POST['delete_resource'])
		{
			Header('Location: deleterule_main_page.php?project_id='.$_REQUEST['project_id'].'&entity_id='.$_REQUEST['entity_id'].'&rule_id='.get_uid_rule());
		}
		else if($_POST['editrule'])
		{
			$current_rule = get_rule_info($_POST['rule_id']);
			$edited_rule = Array('resource_id'=>$current_rule['resource_id'],
				 'owner'=>$current_rule['owner'],
				'project_id'=>$current_rule['project_id'],
				 'rule_id'=>$_POST['rule_id'],
				 'subject'=>$current_rule['subject'],
				 'verb'=>$_POST['verb'],
				 'object'=>$_POST['object'],
				 'notes'=>nl2br($_POST['notes']));
			
					
			$validity = validate_inputs($edited_rule, 'edit');
			//echo $validity;
			switch($validity)
			{
				case 0:
					if(update_rule($edited_rule))
					{
						//echo " here again";
						Header('Location: index_main_page.php?project_id='.$_REQUEST['project_id'].'&entity_id='.$_REQUEST['entity_id'].'');
						//Header('Location: index.php?page='.$_SESSION['current_page']);
					}
	
				case 2:
					$tpl->set_var('subject_required', '');
					$tpl->set_var('verb_required', '*');
					$tpl->set_var('object_required', '');
					$tpl->set_var('action_message', 'Verb is required');
					$edited_rule = $current_rule;
					$edited_rule['verb'] = $_POST['verb'];	
					break;
				case 3:
					$tpl->set_var('subject_required', '');
					$tpl->set_var('verb_required', '');
					$tpl->set_var('object_required', '*');
					$tpl->set_var('action_message', 'Object is required');
					$edited_rule = $current_rule;
					$edited_rule['object'] = $_POST['object'];	
					break;
					
				default:
					break;
			}
			//$tpl->set_var('owner', $_SESSION['user']['account_lid']);
			$tpl->set_var('owner', $edited_rule['owner']);
			$tpl->set_var('action_name','editrule'); 
			$tpl->set_var('action_value','Update'); 
			$tpl->set_var('edit_message', 'Update Rule');
			$tpl->set_var('subject', $edited_rule['subject']);
			$tpl->set_var('verb', '<input name="verb" style="background: lightyellow" value="'.$edited_rule['verb'].'" size="10"></td>'); 
			$tpl->set_var('object', '<input name="object" style="background: lightyellow" value="'.$edited_rule['object'].'" size="10"></td>'); 
			//$tpl->set_var('verb', $edited_rule['verb']);
			//$tpl->set_var('object', $edited_rule['object']);
			$tpl->set_var('notes', $edited_rule['notes']);
			$tpl->set_var('created_on', $edited_rule['created_on']); 
			$tpl->set_var('displayed_rule_id',$edited_rule['rule_id']); 
			$tpl->set_var('displayed_resource_id', $resource_info['id']); 
		}
		else if($_POST['newrule'])
		{
			//echo $_POST['resource'];
			$newrule = Array('project_id'=>$project_info['id'],
				 'owner'=>$_SESSION['user']['account_lid'],
				 'subject'=>$resource_info['entity'],
				 'verb'=>$_POST['verb'],
				 'object'=>$_POST['object'],
				 'notes'=>nl2br($_POST['notes']));
			$validity = validate_inputs($newrule, 'new');
			switch($validity)
			{
				case 0:
					if(create_rule($newrule))
					{
						Header('Location: index_main_page.php?project_id='.$_REQUEST['project_id'].'&entity_id='.$_REQUEST['entity_id'].'');
						//Header('Location: index.php?page='.$_SESSION['current_page']);
					}
				case 1:
					$tpl->set_var('subject_required', '*');
					$tpl->set_var('verb_required', '');
					$tpl->set_var('object_required', '');
					//$tpl->set_var('action_message', 'Subject is required');
					//$tpl->set_var('action_message', 'You have to select a subject from the avaliable resources');
					break;
				case 2:
					$tpl->set_var('subject_required', '');
					$tpl->set_var('verb_required', '*');
					$tpl->set_var('object_required', '');
					$tpl->set_var('action_message', 'Verb is required');
					break;
				case 3:
					$tpl->set_var('subject_required', '');
					$tpl->set_var('verb_required', '');
					$tpl->set_var('object_required', '*');
					$tpl->set_var('action_message', 'Object is required');
					break;
				case 4:
					$tpl->set_var('action_message', 'Rule: ['.$newrule['subject'].' | <b>'.$newrule['verb'].'</b> | '.$newrule['object'].'] already exists');
				default:
					break;
			}
			//$tpl->set_block('rule', 'edit_rule', '_rule');
       			//$tpl->fp('_output', 'edit_rule', True);
			$tpl->set_var('owner', $_SESSION['user']['account_lid']);
			$tpl->set_var('action_name','newrule'); 
			$tpl->set_var('action_value','Create'); 
			$tpl->set_var('subject', $newrule['subject']);
			$tpl->set_var('verb', '<input name="verb" style="background: lightyellow" value="'.$newrule['verb'].'" size="10"></td>'); 
			$tpl->set_var('object', '<input name="object" style="background: lightyellow" value="'.$newrule['object'].'" size="10"></td>'); 
			//$tpl->set_var('verb', $newrule['verb']);
			//$tpl->set_var('object', $newrule['object']);
			$tpl->set_var('notes', $newrule['notes']);
			$tpl->set_var('displayed_rule_id','New'); 
			$tpl->set_var('displayed_resource_id', $resource_info['id']); 

			$tpl->set_var('edit_message', 'Create New Rule');
		}
		else
		{
			$tpl->set_var('action_message', '* required');	
			$tpl->set_var('subject_required', '*');
			$tpl->set_var('object_required', '*');
			$tpl->set_var('verb_required', '*');
			$tpl->set_var('owner', $_SESSION['user']['account_lid']);
			$tpl->set_var('action_name','newrule'); 
			$tpl->set_var('action_value','Create'); 
		 	$tpl->set_var('subject', $resource_info['entity']);
			$tpl->set_var('verb', '<input name="verb" style="background: lightyellow" value="" size="10"></td>'); 
			$tpl->set_var('object', '<input name="object" style="background: lightyellow" value="" size="10"></td>'); 
			$tpl->set_var('displayed_rule_id','New'); 
			$tpl->set_var('displayed_resource_id', $resource_info['id']); 

			$tpl->set_var('edit_message', 'Create New Rule');
		}
	}
	//$tpl->set_block('rule', 'bottom', '_rule');
       	//$tpl->fp('_output', 'bottom', True);
       # $tpl->parse('_output', 'footer', True);
        $tpl->pfp('out','_output');
		
	function list_rules()
	{
		global $resource_info, $project_info;
		$db = $_SESSION['db'];
		$sql = "select * from s3db_rule where project_id='".$project_info['id']."' and subject='".$resource_info['entity']."' and verb !='has UID' and object !='UID' order by verb, object" ;
		//$sql = "select re.project_id, r.resource_id, r.rule_id, r.owner, r.subject, r.verb, r.object, r.notes, r.created_on from s3db_rule as r, s3db_resource as re  where re.resource_id = r.resource_id and r.resource_id='".$_SESSION['working_resource']."'" ;
		//echo $sql;	
		$db->query($sql, __LINE__, __FILE__);
		
		while($db->next_record())
		{
			$rules[] = Array('resource_id' => $db->f('resource_id'), 
					 'project_id' => $db->f('project_id'),
					 'rule_id' => $db->f('rule_id'),
					// 'owner' => $db->f('owner'),
					 'subject' => $db->f('subject'),
					 'verb' => $db->f('verb'),
					 'object' =>$db->f('object'),
					 'notes' => $db->f('notes'),
					 'created_by' =>$db->f('created_by'),
					 'created_on' =>$db->f('created_on'));
		}
		return $rules;	
	}
	function get_uid_rule()
	{global $resource_info, $project_info;
		$db = $_SESSION['db'];
		$sql = "select rule_id from s3db_rule where project_id='".$project_info['id']."' and subject='".$resource_info['entity']."' and verb = 'has UID' and object = 'UID'";
		$db->query($sql, __LINE__, __FILE__);
		if($db->next_record())
			return $db->f('rule_id');
	}

	function get_rule_info($rule_id)
	{global $resource_info, $project_info;
		$db = $_SESSION['db'];
		$sql = "select * from s3db_rule where rule_id='".$rule_id."'";
		$db->query($sql, __LINE__, __FILE__);

		if($db->next_record())
		{
			$rule = Array('rule_id'=>$db->f('rule_id'),
					'project_id'=>$db->f('project_id'),	
					//'owner'=>$db->f('owner'),	
					'subject'=>$db->f('subject'),	
					'verb'=>$db->f('verb'),	
					'object'=>$db->f('object'),	
					'notes'=>$db->f('notes'),	
					'created_on'=>substr($db->f('created_on'), 0, 19),	
					'created_by'=>$db->f('created_by'),	
					'modified_on'=>$db->f('modified_on'),	
					'modified_by'=>$db->f('modified_by'));
		}
		return $rule;
	}
		
	function validate_inputs($rule, $action)
	{global $resource_info, $project_info;
		//print_r($rule);
		if($rule['subject'] == '')
			return 1;
		else if($rule['verb'] == '')
			return 2;
		else if($rule['object'] == '')
			return 3;
		else if($action =='new' && rule_exists($rule))
			return 4;
		else 
			return 0;
				
	}
		
	function create_rule($newrule)
	{global $resource_info, $project_info;
		$db = $_SESSION['db'];
		//$sql = "insert into s3db_rule (project_id, owner, subject, verb, object, notes, created_on, created_by) values ('".$newrule['project_id']."', '".$newrule['owner']."','".$newrule['subject']."','".$newrule['verb']."','".$newrule['object']."','".$newrule['notes']."', now(),'".$_SESSION['user']['account_id']."')";
		$sql = "insert into s3db_rule (project_id, subject, verb, object, notes, created_on, created_by) values ('".$newrule['project_id']."', '".$newrule['subject']."','".$newrule['verb']."','".$newrule['object']."','".$newrule['notes']."', now(),'".$_SESSION['user']['account_id']."')";
		$db->query($sql, __LINE__, __FILE__);
		$rule_id = $db->get_last_insert_id('s3db_rule', 'rule_id');
		if($rule_id != -1)
		{
			$sql ="insert into s3db_rule_change_log (project_id, rule_id, action, action_by, action_timestamp, new_subject, new_verb, new_object, new_notes) values ('".$newrule['project_id']."', '".$rule_id."', 'create', '".$_SESSION['user']['account_lid']."', now(), '".$newrule['subject']."', '".$newrule['verb']."', '".$newrule['object']."', '".$newrule['notes']."')";
			$db->query($sql, __LINE__, __FILE__);
			$newrule['rule_id'] = $rule_id;
			return True;	
		}
		return False;	
	}

	function rule_exists($rule)
	{global $resource_info, $project_info;
		$db = $_SESSION['db'];
		$sql = "select rule_id from s3db_rule where subject='".$rule['subject']."' and verb='".$rule['verb']."' and object='".$rule['object']."' and project_id='".$rule['project_id']."'";
		//echo $sql;
		$db->query($sql, __LINE__, __FILE__);
		if($db->next_record())
			return True;
		else	
			return False;
	}

	
	function update_rule($edited_rule)
	{global $resource_info, $project_info;
		//print_r($edited_rule);
		$db = $_SESSION['db'];
		$rule = get_rule_info($edited_rule['rule_id']);
		$sql ="insert into s3db_rule_change_log (project_id, rule_id, action, action_by, action_timestamp, old_subject, old_verb, old_object, old_notes, new_subject, new_verb, new_object, new_notes) values ('".$edited_rule['project_id']."', '".$edited_rule['rule_id']."', 'modify', '".$_SESSION['user']['account_lid']."', now(), '".$edited_rule['subject']."', '".$edited_rule['verb']."', '".$edited_rule['object']."', '".$edited_rule['notes']."', '".$rule['subject']."', '".$rule['verb']."', '".$rule['object']."', '".$rule['notes']."')";
		$db->query($sql, __LINE__, __FILE__);
		//if($_SESSION['user']['account_lid'] == $edited_rule['owner'])
		$sql = "update s3db_rule set subject='".$edited_rule['subject']."', verb='".$edited_rule['verb']."', object='".$edited_rule['object']."', notes='".$edited_rule['notes']."', modified_on=now(), modified_by='".$_SESSION['user']['account_id']."' where rule_id ='".$edited_rule['rule_id']."'";
		//echo $sql;
		$db->query($sql, __LINE__, __FILE__);
		return True;
	}	
 	
	function render_rules($datasource, $order, $direction)
	{global $resource_info, $project_info;
		$_SESSION['current_color']='0';
		$_SESSION['previous_verb']='';
		//print_r($datasource);
		// Determine sort order and direction as well as the page to display
		$orderBy = $order;
		$dir = $direction;			
		// Create the DataGrid, bind it's Data Source
		 $how_many = ($_SESSION['num_per_page'] !='')?$_SESSION['num_per_page']:50; // Display 50 per page
                if(intVal($how_many) < count($datasource))
                        $dg =& new Structures_DataGrid($how_many);
                else
                        $dg =& new Structures_DataGrid();

	//	$dg =& new Structures_DataGrid(15); // Display 20 per page
		$dg->bind($datasource);	
		// Define DataGrid's columns		
		//$dg->addColumn(new Structures_DataGrid_Column('Resource ID', null, 'resource_id', array('width'=>'7%', 'align'=>'left'), null, 'printResourceID()'));
		$dg->addColumn(new Structures_DataGrid_Column('Rule ID', null, 'rule_id', array('width'=>'7%', 'align'=>'left'), null, 'printRuleID()'));
		$dg->addColumn(new Structures_DataGrid_Column('Owner', null, 'owner', array('width'=>'5%', 'align'=>'left', 'valign'=>'top'), null, 'printOwner()'));
		$dg->addColumn(new Structures_DataGrid_Column('Created On', null, 'created_on', array('width'=>'12%', 'align'=>'left', 'valign'=>'top'), null, 'printCreatedOn()'));
		$dg->addColumn(new Structures_DataGrid_Column('Subject', null, 'subject', array('width'=>'10%', 'align'=>'left', 'valign'=>'top'), null, 'printSubject()'));
		$dg->addColumn(new Structures_DataGrid_Column('Verb', null, 'verb', array('width'=>'10%', 'align'=>'left', 'valign'=>'top'), null, 'printVerb()'));
		$dg->addColumn(new Structures_DataGrid_Column('Object', null, 'object', array('width'=>'10%', 'align'=>'left','valign'=>'top'), null, 'printObject()'));
		$dg->addColumn(new Structures_DataGrid_Column('Notes', null, 'notes', array('width'=>'35%', 'align'=>'left', 'valign'=>'top'), null, 'printNotes()'));
		$dg->addColumn(new Structures_DataGrid_Column('Action', null, null, array('width'=>'15%', 'align'=>'left', 'valign'=>'top'), null, 'printActionLink()'));
		//$dg->addColumn(new Structures_DataGrid_Column('Edit', null, null, array('align'=>'left'), null, 'printEditLink()'));
		//$dg->addColumn(new Structures_DataGrid_Column('Delete', null, null, array('align'=>'left'), null, 'printDeleteLink()'));
		
		// Define the Look and Feel
		//$dg->renderer->setTableHeaderAttributes(array('bgcolor'=>'#FFCCFF'));		
		$dg->renderer->setTableHeaderAttributes(array('bgcolor'=>'lightyellow'));		
		$dg->renderer->setTableEvenRowAttributes(array('bgcolor'=>'#FFFFFF'));		
		$dg->renderer->setTableOddRowAttributes(array('bgcolor'=>'#EEEEEE'));		
		$dg->renderer->setTableAttribute('width', '100%');		
		$dg->renderer->setTableAttribute('align', 'center');		
		$dg->renderer->setTableAttribute('border', '0px');		
		$dg->renderer->setTableAttribute('cellspacing', '0');		
		$dg->renderer->setTableAttribute('cellpadding', '4');		
		$dg->renderer->setTableAttribute('class', 'datagrid');		
		$dg->renderer->sortIconASC = '&uarr;';		
		$dg->renderer->sortIconDESC = '&darr;';	
		
		$htmloutput =  $dg->render();	
		//echo $dg->renderer->getPaging();
		$htmloutput .= $dg->renderer->getPaging();

		return $htmloutput;
	}	
		
	function printResourceID($params)
	{global $resource_info, $project_info;
		extract($params);
		return $record['resource_id'];
	}	
	
	function printRuleID($params)
	{global $resource_info, $project_info;
		extract($params);
		return $record['rule_id'];
	}	
	
	function printOwner($params)
	{
		extract($params);
		return find_user_loginID($record['created_by']);
	}
	
	function printCreatedOn($params)
	{
		extract($params);
		return substr($record['created_on'], 0, 19);
	}

	function printSubject($params)
	{
		extract($params);
		
		return $record['subject'];
	}
		
	function printVerb($params)
	{
		extract($params);
		if($_SESSION['previous_verb'] =='')
			$_SESSION['previous_verb'] = $record['verb'];
		else if(!strsimilar($_SESSION['previous_verb'], $record['verb']))
		//else if($_SESSION['previous_verb'] != $record['verb'])
		{
			$_SESSION['previous_verb'] = $record['verb'];
			$_SESSION['current_color'] = intVal($_SESSION['current_color']) + 1;	
		}
		switch(intVal($_SESSION['current_color'])%3)
		{
			case 0:
				return '<font color="red">'.$record['verb'].'</font>';
			case 1:
				return '<font color="green">'.$record['verb'].'</font>';
			case 2:
				return '<font color="blue">'.$record['verb'].'</font>';
		}
		//return $record['verb'];
	}
	
	 function printActionLink($params)
        {global $resource_info, $project_info;
                extract($params);
		//echo $record['owner'];
		//echo $_SESSION['user']['account_lid'];
		if($record['owner'] == $_SESSION['user']['account_lid'] || $project_info['owner'] == $_SESSION['user']['account_id'] || get_permissions() == '3')
		{
			//if($record['verb'] == 'hasUID' && $record['object'] =='UID')
                	//	return  printEditLink($params);
                	//else
				return  printEditLink($params). ' '.printDeleteLink($params);
		}
		else
			//return "View only";
			return "No Permission";
        }

	function printEditLink($params)
	{
		extract($params);
		//return '<a href="index.php?rule_id='.$record['rule_id'].'&action=edit" title="Update rule '.$record['rule_id'].'">Update</a>';
		return '<a href="index_main_page.php{get_proj_id}{get_res_id}&rule_id='.$record['rule_id'].'&action=edit" title="Edit rule '.$record['rule_id'].'">Edit</a>';
		/*if($record['owner'] == $_SESSION['user']['account_lid'] || get_project_owner() == $_SESSION['user']['account_lid'] || get_permissions($record['project_id']) == '3')
		{
			//echo " I am here";
		}
		else
		{
			//echo " I am here";
			return '&nbsp;';
		}*/
	}	
	
	function get_permissions()
	{global $resource_info, $project_info;
		$db= $_SESSION['db'];
		$sql = "select acl_rights from s3db_project_acl where acl_project_id ='".$project_info['id']."' and acl_account='".$_SESSION['user']['account_id']."'";
		$db->query($sql, __LINE__, __FILE__);
		//echo $sql;
		if($db->next_record())
			return $db->f('acl_rights');
		return '';
	}
	
	function printDeleteLink($params)
	{
		extract($params);
		return '<a href="deleterule_main_page.php{get_proj_id}{get_res_id}&rule_id='.$record['rule_id'].'&action=delete" title="Delete rule '.$record['rule_id'].'">Delete</a>';
		/*if($record['owner'] == $_SESSION['user']['account_lid'] || get_project_owner() == $_SESSION['user']['account_lid'] || get_permissions($record['project_id']) == '3')
			//return '<a href="" onclick="return confirmAction(\'Do you really want to delete rule '.$record['rule_id'].'?\','.$record['rule_id'].')" title="Delete rule '.$record['rule_id'].'">Delete</a>';
		else
			return '&nbsp;';
		*/
	}	
	
	function printNothing($params)
	{
		extract($params);
		return '';
	}	
	
	function printObject($params)
	{
		extract($params);
		return $record['object'];
	}
	
	function printNotes($params)
	{
		extract($params);
		return $record['notes'];
	}

	function printRulesLink($params)
	{
		extract($params);
		if($record['project_status'] == 'A')
			return '<a href="../rule/index_main_page.php{get_proj_id}{get_res_id}&id='.$record['project_id'].'" title="Working on rules associated with project ('.$record['project_name'].')">Rules</a>';
		
		else
			return '';
	}
	
	function printStatementsLink($params)
	{
		extract($params);
		if($record['project_status'] == 'A')
			return '<a href="../statement/index.php{get_proj_id}{get_res_id}&id='.$record['project_id'].'" title="Working on statements associated with project ('.$record['project_name'].')">Statements</a>';
			//return '<a href="../statement/index.php?id='.$record['project_id'].'">Statement</a>';
		else
			return '';
	}

	function printMapLink($params)
	{
		extract($params);
		if($record['project_status'] == 'A')
			return '<a href="../map/index.php{get_proj_id}{get_res_id}&id='.$record['project_id'].'">Map</a>';
		else
			return '';
	}
	
	function get_project_info($project_id)
	{
		$db = $_SESSION['db'];
		$sql = "select * from s3db_project where project_id='".$project_id."'";
		$db->query($sql, __LINE__, __FILE__);
		if($db->next_record())
		{
			$project_info=Array('project_id'=>$db->f('project_id'),
					   'project_name'=>$db->f('project_name'),
					   'project_owner'=>$db->f('project_owner'),
					   'project_description'=>$db->f('project_description'),
					   'project_status'=>$db->f('project_status'),
					   'created_on'=>$db->f('created_on'),
					   'created_by'=>$db->f('created_by'),
					   'modified_on'=>$db->f('modified_on'),
					   'modified_by'=>$db->f('modified_by'));

		} 
		return $project_info;
	}
	
?>
